<?php
     // Start session    
    session_start();

    // Include configuration file
    include "../config.php";

    // Check if the connection is set and if the "more_info" form is submitted
    if(isset($conn) && isset($_POST["more_info"])){

    // Set timezone to Melbourne, Australia
    date_default_timezone_set('Australia/Melbourne');
    // Set default value for year
    $year = "";

    // Check if a specific year is submitted, otherwise use current year
    if(isset($_POST["year"])){
        $year = intval($_POST["year"]);
    }else{
        $year = intval(date('Y'));
    }

    // Get user id from the form submission
    $id_user = intval($_POST["id_user"]);

    // Set initial values for variables related to user expertise, number of students, support received, and recommendation
    $expertise = "N/A";
    $number_of_student = 0;
    $supported = 0;
    $recommendation = "N/A";

    // Query the database to check if more info is already saved for this user
    $sql_info = mysqli_query($conn, "SELECT id, expertise, supported, recommendation FROM more_info WHERE id_user=$id_user");
    
    // If more info is already saved, retrieve the data and assign it to respective variables
    if(mysqli_num_rows($sql_info) > 0){
        $more_info = mysqli_fetch_array($sql_info, MYSQLI_ASSOC);
        $expertise = strtolower($more_info["expertise"]);
        $supported = intval($more_info["supported"]);
        $recommendation = mysqli_real_escape_string($conn, $more_info["recommendation"]);

    // If more info is not yet saved, insert default values for the user
    }else{
        mysqli_query($conn, "INSERT INTO more_info(id_user, expertise, supported, recommendation) VALUES($id_user,'$expertise',$supported,'$recommendation')");
    }

    // Retrieve user details from database based on user id
    $user = mysqli_fetch_array(mysqli_query($conn, "SELECT id, id_role, id_qualification, first_name, last_name, load_user, status FROM user WHERE id=$id_user"), MYSQLI_ASSOC);
    
    // Sets the width size of the table and calendar.
    echo "<div class='myTable' >"; 

    // Sets up a row and column layout with certain height and style.
    echo "<div class='row g-3' style='height: 80%'>";
    echo "<div class='col-md-6' style='height: 100%;'>";
    echo "<div class='row g-3 style5' style='margin-top:10px;'>";

    // Sets the value of the input field for the staff member's name.
    echo "<div class='col-sm-6'>";
            $name = ucfirst(strtolower($user["first_name"]))." ".ucfirst(strtolower($user["last_name"]));
    echo "<label for='staff_name' class='form-label'>Staff Member</label>";
    echo "<input type='text' class='form-control' id='staff_name' placeholder='' value='$name' disabled>";
    echo "</div>";

    // Sets the value of the input field for the staff member's expertise.
    echo "<div class='col-sm-6'>";
    echo "<label for='staff_expertise' class='form-label'>Expertise</label>";
    echo "<input type='text' class='form-control' id='staff_expertise' placeholder='' value='$expertise' required>";
    echo "</div>";

    // Sets the value of the input field for the total number of instances/subjects in a year.
    echo "<div class='col-sm-6'>";
        $number_of_subject_tot = mysqli_fetch_array(mysqli_query($conn, "SELECT count(id_subject) AS num_subject FROM schedule, instance WHERE schedule.id_instance=instance.id AND year=$year AND id_user=$id_user"), MYSQLI_ASSOC)["num_subject"];
    echo "<label for='staff_tot_subject' class='form-label'># Of Instances / Subjects (in $year)</label>";
    echo "<input type='text' class='form-control' id='staff_tot_subject' placeholder='' value='$number_of_subject_tot' disabled>";
    echo "</div>";

    // Sets the value of the input field for the total number of students.
    //    echo "<div class='col-sm-6'>";
    //    echo "</div>";

    // Sets the value of the input field for whether the staff member is supported or not.
    echo "<div class='col-sm-6'>";
    echo "<label for='staff_supported' class='form-label'>Supported?</label>";
    echo "<select class='form-control' id='staff_supported' required>";
    echo "<option value='0'>No</option>";
    echo "<option value='1'>Yes</option>";
    echo "</select>";
    echo "<script>$('#staff_supported').val($supported);</script>";
    echo "</div>";

    // Sets the value of the input field for the staff member's load.
    echo "<div class='col-sm-6'>";
    echo "<label for='staff_load' class='form-label'>Load</label>";
    echo "<input type='text' class='form-control' id='staff_load' placeholder='' value='$user[load_user]' disabled>";
    echo "</div>";

    // Sets the value of the input field for the staff member's role.
    echo "<div class='col-sm-6'>";
        $role = strtolower(mysqli_fetch_array(mysqli_query($conn, "SELECT id, name FROM role WHERE id=$user[id_role]"), MYSQLI_ASSOC)["name"]);
    echo "<label for='staff_role' class='form-label'>Role</label>";
    echo "<input type='text' class='form-control' id='staff_role' placeholder='' value='$role' disabled>";
    echo "</div>";

    // Sets the value of the input field for the staff member's if they are part time or full time.
    echo "<div class='col-sm-6'>";
        $status = "Full-Time";
        if($user['status'] == 0){
            $status = "Part-Time";
        }
    echo "<label for='staff_status' class='form-label'>Role Type</label>";
    echo "<input type='text' class='form-control' id='staff_status' placeholder='' value='$status' disabled>";
    echo "</div>";


    // input field for the staff member's recommendation notes.
    echo "<div class='col-sm-12'>";
    echo "<label for='staff_rec' class='form-label'>Recommendation</label>";
    echo "<textarea class='form-control' id='staff_rec' placeholder='' style='resize: none; height: 50px;' required>$recommendation</textarea>";
    echo "</div>";
    echo "</div>";
    echo "</div>";

    // Displays a row of chevron icons and the current year, with an onclick event that calls a JavaScript function 'change_year()'.
    echo "<div class='col-md-6' style='height: 100%;'>";
    echo "<div class='row g-3 style5' style='height: 20%; padding: 20px;'>";
    echo "<div class='col-sm-12 center_row'>";
    echo "<img src='img/chevron-left.svg' style='width: 40px; margin-right: 40px; cursor:pointer;' onclick='change_year($id_user, -1)'>";
    echo "<span id='current_year' style='font-weight: bold; font-size: 2em;'>$year</span>";
    echo "<img src='img/chevron-right.svg' style='width: 40px; margin-left: 40px; cursor: pointer;' onclick='change_year($id_user, 1)'>";
   
    echo "</div>";
    echo "</div>";


    // Displays a row of monthly containers, each containing the month name and the total number of subjects scheduled for that month.
    // The background color of each container depends on the number of subjects scheduled for that month.
    // The for loop iterates through each month and retrieves the number of subjects scheduled for that month using SQL queries.
    echo "<div class='row g-3 style5' style='height: 100%;'>"; // changes height size of calendar on More Info Page.
            for($i=1; $i<13; $i++){
                $number_of_subject_month = mysqli_fetch_array(mysqli_query($conn, "SELECT count(id_subject) AS num_subject FROM schedule, instance WHERE schedule.id_instance=instance.id AND month=$i AND year=$year"), MYSQLI_ASSOC)["num_subject"];
                $dateObj   = DateTime::createFromFormat('!m', $i);
                $monthName = $dateObj->format('F');
                $month_color = "#6bff7c";
                if($number_of_subject_month > 11 && $number_of_subject_month<20){
                    $month_color = "#ffe46b";
                }elseif($number_of_subject_month >= 30){
                    $month_color = "#ff6b6b";
                }
    echo "<div class='col-sm-3'>";
    echo "<div class='container_month space_evenly_col' onclick='loadScheduleTable($id_user, $i, $year)' style='background-color: $month_color;' title='Number of Subjects: $number_of_subject_month'>";
    echo "<span style='font-weight: bold;'>$monthName</span>";
    echo "<span>Total: <b>$number_of_subject_month</b></span>";
    echo "</div>";
    echo "</div>";
        }

    echo "<div class='col-sm-12'>";
    echo "<div id='schedule-wrapper'>";

    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    echo "</div>";
    
    echo "</div>";

    // Add buttons and script to bottom of page  
    echo "<div class='myTable' >"; // Aligns bottom buttons to center and width alignment shorter.
    echo "<div class='row' style='height: 4%;'>";

    // save changes button bottom of page
    echo "<div class='col-md-6 center_row'>";
    echo "<button class='btn_base btn_save_changes' onclick='try_edit_more_info($id_user)'>SAVE CHANGES</button>";
    echo "</div>";
 
    // previous page button bottom of page    
    echo "<div class='col-md-6 center_row'>";
    echo "<button class='btn_base btn_grey' onclick='cancel(1)'>PREVIOUS PAGE</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";

    // Set the current path in the script  
    echo "<script>set_current_path('More Info')</script>";
    }
?>