<?php
// Start session
session_start();

// Include configuration file
include "../config.php";

//check if the connection is set and add_user is set
if(isset($conn) && isset($_POST["schedule"])){

    echo "<script>clear_schedule_array();</script>";

    // Create a variable key to be used in SQL query
    $key = "";
    $year = $_POST['year'];
    $month = $_POST['month'];

    // Perform SQL query to retrieve Schedule from database
    $sql = mysqli_query($conn, "SELECT schedule.id AS id, id_user, id_subject, id_instance, schedule.active AS active FROM schedule, subject, instance, user WHERE schedule.id_user=user.id AND instance.month=$month AND instance.year=$year AND schedule.id_subject=subject.id AND schedule.id_instance=instance.id ORDER BY instance.month, instance.year ASC");

    // This PHP code block generates an HTML table with Schedule and their details, as well as buttons to add, edit, delete, and mark inactive Schedule.
    // It also includes a search bar to filter the Schedule displayed in the table.
    echo "<div class='row container_table' style='padding: 5px;'>";
    echo "<div class='col-md-12' style='height: 90%; max-height: 250px; overflow: auto;'>";
    echo "<table class='max_width table style5' style='width: 100%;'>";
    echo "<tr class='index_table'>";
    if(isset($_POST['is_edit_schedule']) && $_POST['is_edit_schedule']) {
        echo "<td style='padding: 10px 0;'>";
        echo "<span>Select</span>";
        echo "</td>";
    }

    echo "<td>";
    echo "<span>User Name</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Load</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Subject Code</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Subject Name</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Active</span>";
    echo "</td>";
    echo "</tr>";

    // Initialize a counter to alternate the background color of the table rows.
    $i = 0;
    if(mysqli_num_rows($sql) > 0) {
        // Loop through each schedule record in the database query result.
        while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
            $user = mysqli_fetch_array(mysqli_query($conn, "SELECT id, first_name, last_name, load_user FROM user WHERE id=$vet[id_user]"), MYSQLI_ASSOC);
            $subject = mysqli_fetch_array(mysqli_query($conn, "SELECT id, name, code FROM subject WHERE id=$vet[id_subject]"), MYSQLI_ASSOC);
            $instance = mysqli_fetch_array(mysqli_query($conn, "SELECT id, instance, term, month, year FROM instance WHERE id=$vet[id_instance]"), MYSQLI_ASSOC);

            // Set background color of each row alternatively.
            $color = "#fff";
            if($i%2 != 0){
                $color = "#F5F5F5FF";
            }
            $i++;

            // Output the table row for each record.
            echo "<tr class='record_table' style='background-color: $color;'>";
            if(isset($_POST['is_edit_schedule']) && $_POST['is_edit_schedule']) {
                echo "<td style='padding: 10px 0;'>";
                // Output a checkbox in the first cell of the row.
                echo "<input type='checkbox' onchange='select_schedule($vet[id])'>";
                echo "</td>";
            }

            // Output the user id in the third cell of the row.
            // Output the first and last name in the cell of the row.
            echo "<td>";
            $name = ucfirst(strtolower($user['first_name']))." ".ucfirst(strtolower($user['last_name']));
            echo "<span>$name</span>";
            echo "</td>";

            // Output the user load in the cell of the row
            echo "<td>";
            echo "<span>$user[load_user]</span>";
            echo "</td>";

            // Output the subject code in the cell of the row.
            echo "<td>";
            echo "<span>$subject[code]</span>";
            echo "</td>";

            // Output the subject name in the cell of the row.
            echo "<td>";
            echo "<span>$subject[name]</span>";
            echo "</td>";
            // Output the month in the cell of the row.


            // Output whether the schedule is active or not in the cell of the row.
            echo "<td>";
            $active = "No";
            if($vet['active'] == 1){
                $active = "Yes";
            }
            echo "<span>$active</span>";
            echo "</td>";

            // Close the table row for the current record.
            echo "</tr>";
        }
    }else{
        echo "<tr > <td colspan='6'>Not Available</td></tr>";
    }


    // Close the table and div elements for the records section.
    echo "</table>";
    echo "</div>";
    echo "</div>";

}

?>