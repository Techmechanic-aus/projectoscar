<?php
    // Start session   
    session_start();

    // Include configuration file  
    include "../config.php";

    // Check if database connection and add_schedule parameter are set
    if (isset($conn) && isset($_POST["add_schedule"])){

    // Set timezone to Australia/Melbourne
    date_default_timezone_set('Australia/Melbourne');
    $current_year = date('Y');

    // Query to select user details
    $sql_user = mysqli_query($conn, "SELECT id, first_name, last_name, load_user FROM user WHERE id NOT IN (1, 2)");
    
    // Query to select subject details
    $sql_subject = mysqli_query($conn, "SELECT id, code, name FROM subject WHERE id!=3");
   
    // Display table container 
    echo "<div class='row container_table'>";
?>

   <!--Start of form elements-->   
    <div class="col-md-7 col-lg-8 max_width center_col">
        <form class="needs-validation eighty_width" novalidate>
            <div class="row g-3">

                <!-- Form Element - User select dropdown --> 
                <div class="col-sm-6">
                    <label for="add_user_schedule" class="form-label">User</label>
                    <select class="form-control" id="add_user_schedule" required>
                    <?php

                        // Loop through users and display as options in dropdown                    
                        while($vet = mysqli_fetch_array($sql_user, MYSQLI_ASSOC)){
                            
                            $name = ucfirst(strtolower($vet['first_name']));
                            $surname = ucfirst(strtolower($vet['last_name']));
                            $load = ucfirst(strtolower($vet['load_user']));
                            $option_text = "$name $surname [ id: $vet[id] ] [ load: $vet[load_user] ]";
                            
                            // Add warning for overloaded users                            
                            if ($load >= 2.2) {
                                $option_text .= " (WARNING: OVER LOADED)";
                                echo "<option value='$vet[id]' data-load='$vet[load_user]' style='color: red;'>$option_text</option>";
                            } else {
                                echo "<option value='$vet[id]' data-load='$vet[load_user]'>$option_text</option>";
                            }
                        }
                        ?>
                    </select>
                </div>  

                <!-- Form Element - Subject select dropdown -->
                <div class="col-sm-6">
                    <label for="add_subject_schedule" class="form-label">Subject</label>
                    <select class="form-control" id="add_subject_schedule" required>
                        <?php
                        // Loop through subjects and display as options in dropdown                        
                        while($vet = mysqli_fetch_array($sql_subject, MYSQLI_ASSOC)){
                            $name = ucfirst(strtolower($vet['name']));
                            echo "<option value='$vet[id]'>$name [ code: $vet[code] ]</option>";
                        }
                        ?>
                    </select>
                </div>

                <!-- Form Element - Instance input field -->    
                <div class="col-sm-6">
                    <label for="add_instance_schedule" class="form-label">Instance</label>
                    <input type="number" class="form-control" id="add_instance_schedule" placeholder="" value="1" min="1" required>
                </div>
                
                <!-- Form Element - Term input field -->
                <div class="col-sm-6">
                    <label for="add_term_schedule" class="form-label">Term</label>
                    <input type="number" class="form-control" id="add_term_schedule" placeholder="" value="1" min="1" required>
                </div>

                <!-- Form Element - Course Month/Year input field -->
                <div class="col-sm-6">
                    <label for="add_month_schedule" class="form-label">Course Month/Year</label>
                    <input type="month" class="form-control" id="add_month_schedule" placeholder="040045124" value="" required>
                </div>

                <!-- Form Element - Active select dropdown -->
                <div class="col-sm-6">
                    <label for="add_active" class="form-label">Active</label>
                    <select id="add_active" class="form-control" required>
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                </div>
            </div>
        </form>
    </div>

<!-- Add buttons and script to bottom of page  -->      
<?php
    // Close the first row table container
    echo "</div>";

    // Create a new row for the SAVE and CANCEL buttons       
    echo "<div class='row' style='height: 10%;'>";
    echo "<div class='col-6 end_row'>";

    // Save button
    echo "<button class='btn_base btn_save' onclick='try_add_schedule()'>SAVE</button>";
    echo "</div>";

    // Cancel button 
    echo "<div class='col-6 start_row'>";
    echo "<button class='btn_base btn_cancel' onclick='cancel(6)'>CANCEL</button>";
    echo "</div>";

    // Close the button row  
    echo "</div>";

    // Set the current path in the script 
    echo "<script>set_current_path('Add Schedule')</script>";
    }
?>