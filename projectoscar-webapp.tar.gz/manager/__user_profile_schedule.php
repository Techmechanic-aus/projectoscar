<?php
$year = "";

// Check if a specific year is submitted, otherwise use current year
if(isset($_POST["year"])){
    $year = intval($_POST["year"]);
}else{
    $year = intval(date('Y'));
}

echo "<div class='col-md-6' style='height: 100%;'>";
echo "<div class='row g-3 style5' style='height: 20%; padding: 20px; max-width:75%;'>"; // Chevron Calendar Year Arrows / alignment

echo "<div class='col-sm-12 center_row'>";
echo "<img src='img/chevron-left.svg' style='width: 40px; margin-right: 40px; cursor:pointer;' onclick='change_year_profile( -1)'>";
echo "<span id='current_year' style='font-weight: bold; font-size: 2em;'>$year</span>";
echo "<img src='img/chevron-right.svg' style='width: 40px; margin-left: 40px; cursor: pointer;' onclick='change_year_profile( 1)'>";

echo "</div>";
echo "</div>";


// Displays a row of monthly containers, each containing the month name and the total number of subjects scheduled for that month.
// The background color of each container depends on the number of subjects scheduled for that month.
// The for loop iterates through each month and retrieves the number of subjects scheduled for that month using SQL queries.

echo "<div class='row g-3 style5' style='max-width:80%;'>"; // changes height size of calendar on user_profiles.php page.
for($i=1; $i<13; $i++){
    $number_of_subject_month = mysqli_fetch_array(mysqli_query($conn, "SELECT count(id_subject) AS num_subject FROM schedule, instance WHERE schedule.id_instance=instance.id AND month=$i AND year=$year"), MYSQLI_ASSOC)["num_subject"];
    $dateObj   = DateTime::createFromFormat('!m', $i);
    $monthName = $dateObj->format('F');
    $month_color = "#6bff7c";
    if($number_of_subject_month > 11 && $number_of_subject_month<20){
        $month_color = "#ffe46b";
    }elseif($number_of_subject_month >= 30){
        $month_color = "#ff6b6b";
    }

    echo "<div class='col-sm-3'>";
    echo "<div class='container_month space_evenly_col' onclick='loadScheduleTableOnProfile( $i, $year)' style='background-color: $month_color;' title='Number of Subjects: $number_of_subject_month'>";
    echo "<span style='font-weight: bold;'>$monthName</span>";
    echo "<span>Total: <b>$number_of_subject_month</b></span>";
    echo "</div>";
    echo "</div>";
}
echo "<div class='col-sm-12'>";
echo "<div id='schedule-wrapper'>";

echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";
echo "</div>";