<?php
    // Start session   
    session_start();

    // Include configuration file 
    include "../config.php";

    //check if the connection is set and add_user is set
    if(isset($conn) && isset($_POST["user_profiles"])){
    echo "<script>clear_array();</script>";
   
    // Create a variable key to be used in SQL query
    $key = "WHERE id NOT IN(1,2)";

    // Check if $_POST["key"] is set
    if(isset($_POST["key"])){

        // mysqli_real_escape_string() to prevent SQL injection
        $value = mysqli_real_escape_string($conn, $_POST["key"]);

        // Append to the key variable to filter the SQL query        
        $key .= " AND (first_name LIKE('%$value%') OR last_name LIKE('%$value%') OR email LIKE('%$value%'))";
    }

    // Perform SQL query to retrieve user profile from database
     $sql = mysqli_query($conn, "SELECT id, first_name, last_name, email, load_user, status, active FROM user $key");
     
    // This PHP code block generates an HTML table with user profile and their details. 
    // It also includes a search bar to filter the user profile displayed in the table     
    echo "<div class='row container_table' style='height: 80%'>";
    echo "<div class='col-md-4'></div>";

        echo "<div class='col-md-4 start_row' style='padding-bottom: 5px; height: 10%;'>";
            echo "<input id='key_search' class='form-control' type='search' placeholder='Search User'>";
            echo "<label for='key_search' style='cursor: pointer;' onclick='search()'><img src='img/search.svg' style='margin-left: 16px; width: 20px;'></label>";
        echo "</div>";

    // Left Table positioning.
    echo "<div class='col-md-4'></div>";

    echo "<div class='col-md-6'  style='height: 90%; max-height: 500px; overflow: auto;'>";

    // USer Profiles - Left Table.
    echo "<table class='max_width table style5' style='max-width:60%;'>";  

        // Table sticky Top Row.
        echo "<tr class='index_table'>";

            // Table Content. 
            echo "<td style='padding: 10px 0;'>";
                echo "<span>Select</span>";
            echo "</td>";

            echo "<td>";
                echo "<span>More Info</span>";
            echo "</td>";

            echo "<td>";
                echo "<span>Name</span>";
            echo "</td>";

            echo "<td>";
                echo "<span>Load</span>";
            echo "</td>";

            echo "<td>";
                echo "<span>Status</span>";
            echo "</td>";

            echo "<td>";
                echo "<span>Active</span>";
            echo "</td>";

        echo "</tr>";

        // Initialize a counter to alternate the background color of the table rows.   
        $i = 0;

        // Loop through each subject record in the database query result
        while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
        
        // Set background color of each row alternatively        
        $color = "#fff";
        if($i%2 != 0){
            $color = "#F5F5F5FF";
        }
        $i++;

        // Output the table row for each record.        
        echo "<tr class='record_table' style='background-color: $color;'>";

        // Output a checkbox in the first cell of the row.         
        echo "<td style='padding: 10px 0;'>";
            echo "<input type='checkbox' onchange='select_user($vet[id])'>";
        echo "</td>";

        //  More Info On click button more info page. 
        echo "<td style='cursor: pointer;' onclick='more_info($vet[id])'>";
            echo "<img src='img/more_info.png' style='width: 30px;'>";
        echo "</td>";

        // Output the first and last name in the second cell of the row.
        echo "<td>";
            $name = ucfirst(strtolower($vet['first_name']))." ".ucfirst(strtolower($vet['last_name']));
            echo "<span>$name</span>";
        echo "</td>";

        // Output the users load in the cell of the row.
        echo "<td>";
            echo "<span>$vet[load_user]</span>";
        echo "</td>";
        
        // Output the if the user is part time or full time in the cell of the row.
        echo "<td>";
                $status = "Full-Time";
                    if($vet['status'] == 0){
                    $status = "Part-Time";
                }   
            echo "<span>$status</span>";
        echo "</td>";

        // Output whether the user profile is active or not in the cell of the row
        echo "<td>";
                $active = "No";
                    if($vet['active'] == 1){
                    $active = "Yes";
                }
            echo "<span>$active</span>";
        echo "</td>";

        // Close the table row for the current record.          
        echo "</tr>";
        }

    // Close the table and div elements for the records section.     
    echo "</table>";
        echo "</div>";

            // Adds Calendar and Calendar Table Right Side .
            include "../manager/__user_profile_schedule.php";

        echo "</div>";

        // Add buttons and script to bottom of page  
        echo "<div class='myTable' >"; // Aligns bottom buttons to center and width alignment shorter.
        echo "<div class='row' style='height: 4%;'>";

        // Add staff button bottom of page   
        echo "<div class='col-md-2 center_row'>";
            echo "<button class='btn_base btn_add' onclick='add_user()'>ADD STAFF</button>";
        echo "</div>";

        // edit staff profile button bottom of page 
        echo "<div class='col-md-2 center_row'>";
            echo "<button class='btn_base btn_edit' onclick='edit_account()'>EDIT STAFF</button>";
        echo "</div>";
    
        // edit schedule button bottom of page
        echo "<div class='col-md-2 center_row'>";
            echo "<button class='btn_base btn_edit' onclick='edit_schedule()'>EDIT SCHEDULE</button>";
        echo "</div>";

        // previous page button bottom of page
        echo "<div class='col-md-2 center_row'>";
            echo "<button class='btn_base btn_grey' onclick='cancel(0)'>PREVIOUS PAGE</button>";
        echo "</div>";

        // Close the button row 
        echo "</div>";

        // Set the current path in the script      
        echo "<script>set_current_path('User Profiles')</script>";
    }
?>