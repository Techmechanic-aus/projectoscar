<!-- Manager DASHBOARD Displayed on manager.php -->

<!-- This is a section for displaying buttons that represent different database sections, such as user profiles and schedule -->
<div class="row max_height">
    <div class="col-md-6 center_col">

    <!-- This is a button for accessing the user profiles database section. When clicked, it calls the user_profiles_db() function. -->    
    <div class="p-3 button-30 center_col style4" onclick="user_profiles_db()">USER PROFILES</div>
    </div>

    <!-- This is a button for accessing the schedule database section. When clicked, it calls the schedule_db() function. -->
    <div class="col-md-6 center_col">
     <div class="p-3 button-30 center_col style4" onclick="schedule_db()">SCHEDULER</div>
    </div>

</div>

<!-- This script section sets the current path to "Manager Dashboard" using the set_current_path() function. -->
<script>set_current_path("Manager Dashboard")</script>