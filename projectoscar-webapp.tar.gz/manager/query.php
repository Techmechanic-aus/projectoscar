<?php
    // Start session
    session_start();

    // Include configuration file       
    include "../config.php";

    // Check if connection and post data are set
    if (isset($conn) && isset($_POST["try_add_user"])){

        // Sanitize user input using mysqli_real_escape_string() basic security measures to prevent SQL injection attacks
        $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
        $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
        $email = strtoupper(mysqli_real_escape_string($conn, $_POST["email"]));
        $psw = mysqli_real_escape_string($conn, $_POST["psw"]);
        $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
        $dob = $_POST["dob"];
        $load = floatval($_POST["load"]); // Query for user load value. 
        $status = intval($_POST["status"]);
        $address = mysqli_real_escape_string($conn, $_POST["address"]);
        $suburb = mysqli_real_escape_string($conn, $_POST["suburb"]);
        $postcode = mysqli_real_escape_string($conn, $_POST["postcode"]);
        $role = intval($_POST["role"]);
        $qualification = intval($_POST["qualification"]);
        $active = intval($_POST["active"]);

       // Check if user with given email already exists   
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM user WHERE email='$email'")) == 0){
            
            // If user doesn't exist, insert user data into database            
            if(mysqli_query($conn, "INSERT INTO user(id_role, id_qualification, first_name, last_name, birthday, phone, email, address, suburb, post_code, load_user, status, psw, active) VALUES($role, $qualification, '$first_name', '$last_name', '$dob', '$phone', '$email', '$address', '$suburb', '$postcode', $load, $status, '$psw', $active)")){
                // If insertion is successful, echo 1                
                echo 1;
            }else{
                // If insertion fails, echo 0                
                echo 0;
            }
        }else{
            // If user already exists, echo 2            
            echo 2;
        }

    // Query for modify user details    
    }elseif (isset($conn) && isset($_POST["try_modify_user"])){
        $id_user = intval($_POST["id_user"]);
        $first_name = mysqli_real_escape_string($conn, $_POST["first_name"]);
        $last_name = mysqli_real_escape_string($conn, $_POST["last_name"]);
        $email = strtoupper(mysqli_real_escape_string($conn, $_POST["email"]));
        $psw = mysqli_real_escape_string($conn, $_POST["psw"]);
        $phone = mysqli_real_escape_string($conn, $_POST["phone"]);
        $dob = $_POST["dob"];
        $load = floatval($_POST["load"]); // Query for user load value. 
        $status = intval($_POST["status"]);
        $address = mysqli_real_escape_string($conn, $_POST["address"]);
        $suburb = mysqli_real_escape_string($conn, $_POST["suburb"]);
        $postcode = mysqli_real_escape_string($conn, $_POST["postcode"]);
        $role = intval($_POST["role"]);
        $qualification = intval($_POST["qualification"]);
        $active = intval($_POST["active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM user WHERE email='$email' AND id != $id_user ")) == 0){
            if(mysqli_query($conn, "UPDATE user SET id_role=$role, id_qualification=$qualification, first_name='$first_name', last_name='$last_name', birthday='$dob', phone='$phone', email='$email', address='$address', suburb='$suburb', post_code='$postcode', load_user=$load, status=$status, psw='$psw', active=$active WHERE id=$id_user")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for delete user         
    }elseif (isset($conn) && isset($_POST["try_delete_user"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_account"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "DELETE FROM user WHERE id=$vet_id[$i]")){
                $check = 0;
            }
            if(!mysqli_query($conn, "DELETE FROM schedule WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for inactive user           
    }elseif (isset($conn) && isset($_POST["try_inactive_user"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_account"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "UPDATE user SET active=0 WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for reset user password         
    }elseif (isset($conn) && isset($_POST["try_reset_psw"])){
        $psw = strval($_POST["new_psw"]);
        $id_user = intval($_POST["id_user"]);
        if(mysqli_query($conn, "UPDATE user SET psw='$psw' WHERE id=$id_user")){
            echo 1;
        }else{
            echo 0;
        }

    // Query for adding role          
    }elseif (isset($conn) && isset($_POST["try_add_role"])){
        $role_name = strtolower(mysqli_real_escape_string($conn, $_POST["role"]));
        $description = mysqli_real_escape_string($conn, $_POST["role_description"]);
        $active = intval($_POST["role_active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM role WHERE name='$role_name'")) == 0){
            if(mysqli_query($conn, "INSERT INTO role(name, description, active) VALUES('$role_name','$description',$active)")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for deleting role         
    }elseif (isset($conn) && isset($_POST["try_delete_role"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_role"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "DELETE FROM role WHERE id=$vet_id[$i]")){
                $check = 0;
            }
            if(!mysqli_query($conn, "UPDATE user SET id_role=7 WHERE id_role=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for editing role           
    }elseif (isset($conn) && isset($_POST["try_edit_role"])){
        $id_role = intval($_POST["id_role"]);
        $role_name = strtolower(mysqli_real_escape_string($conn, $_POST["role"]));
        $description = mysqli_real_escape_string($conn, $_POST["role_description"]);
        $active = intval($_POST["role_active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM role WHERE name='$role_name' AND id!=$id_role")) == 0){
            if(mysqli_query($conn, "UPDATE role SET name='$role_name', description='$description', active='$active' WHERE id=$id_role")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for inactive role          
    }elseif (isset($conn) && isset($_POST["try_inactive_role"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_role"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "UPDATE role SET active=0 WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for add subject        
    }elseif (isset($conn) && isset($_POST["try_add_subject"])){
        $subject_name = strtolower(mysqli_real_escape_string($conn, $_POST["subject"]));
        $subject_code = strtoupper(mysqli_real_escape_string($conn, $_POST["subject_code"]));
        $active = intval($_POST["subject_active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM subject WHERE code='$subject_code'")) == 0){
            if(mysqli_query($conn, "INSERT INTO subject(name, code, active) VALUES('$subject_name','$subject_code',$active)")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for edit subject        
    }elseif (isset($conn) && isset($_POST["try_edit_subject"])){
        $id_subject = intval($_POST["id_subject"]);
        $subject_name = strtolower(mysqli_real_escape_string($conn, $_POST["subject"]));
        $code = strtoupper(mysqli_real_escape_string($conn, $_POST["subject_code"]));
        $active = intval($_POST["subject_active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM subject WHERE code='$code' AND id!=$id_subject")) == 0){
            if(mysqli_query($conn, "UPDATE subject SET name='$subject_name', code='$code', active='$active' WHERE id=$id_subject")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for inactive subject          
    }elseif (isset($conn) && isset($_POST["try_inactive_subject"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_subject"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "UPDATE subject SET active=0 WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for delete subject            
    }elseif (isset($conn) && isset($_POST["try_delete_subject"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_subject"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "DELETE FROM subject WHERE id=$vet_id[$i]")){
                $check = 0;
            }
            if(!mysqli_query($conn, "UPDATE schedule SET id_subject=3 WHERE id_subject=$vet_id[$i]")){
                $check = 0;
            }
        }

    // Query for adding qualification          
        echo $check;
    }elseif (isset($conn) && isset($_POST["try_add_qualification"])){
        $qualification_name = strtolower(mysqli_real_escape_string($conn, $_POST["qualification"]));
        $qualification_description = mysqli_real_escape_string($conn, $_POST["qualification_description"]);
        $active = intval($_POST["qualification_active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM qualification WHERE name='$qualification_name'")) == 0){
            if(mysqli_query($conn, "INSERT INTO qualification(name, description, active) VALUES('$qualification_name','$qualification_description',$active)")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for editing qualification         
    }elseif (isset($conn) && isset($_POST["try_edit_qualification"])){
        $id_qualification = intval($_POST["id_qualification"]);
        $qualification_name = strtolower(mysqli_real_escape_string($conn, $_POST["qualification"]));
        $qualification_description = mysqli_real_escape_string($conn, $_POST["qualification_description"]);
        $active = intval($_POST["qualification_active"]);
        if(mysqli_num_rows(mysqli_query($conn, "SELECT id FROM qualification WHERE name='$qualification_name' AND id!=$id_qualification")) == 0){
            if(mysqli_query($conn, "UPDATE qualification SET name='$qualification_name', description='$qualification_description', active='$active' WHERE id=$id_qualification")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }

    // Query for inactive qualification         
    }elseif (isset($conn) && isset($_POST["try_inactive_qualification"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_qualification"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "UPDATE qualification SET active=0 WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for deleting qualification         
    }elseif (isset($conn) && isset($_POST["try_delete_qualification"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_qualification"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "DELETE FROM qualification WHERE id=$vet_id[$i]")){
                $check = 0;
            }
            if(!mysqli_query($conn, "UPDATE user SET id_qualification=3 WHERE id_qualification=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for adding schedule         
    }elseif (isset($conn) && isset($_POST["try_add_schedule"])){
        $user_schedule = intval($_POST["add_user_schedule"]);
        $subject_schedule = intval($_POST["add_subject_schedule"]);
        $instance_schedule = intval($_POST["add_instance_schedule"]);
        $term_schedule = intval($_POST["add_term_schedule"]);
        $course_schedule = explode("-", strval($_POST["add_month_schedule"]));
        $active = intval($_POST["add_active"]);
        if(mysqli_query($conn, "INSERT INTO instance(instance, term, month, year) VALUES($instance_schedule, $term_schedule, $course_schedule[1], $course_schedule[0])")){
            $last_insert = mysqli_fetch_array(mysqli_query($conn, "SELECT id FROM instance ORDER BY id DESC LIMIT 1"), MYSQLI_ASSOC)["id"];
            if(mysqli_query($conn, "INSERT INTO schedule(id_user, id_subject, id_instance, active) VALUES($user_schedule, $subject_schedule, $last_insert, $active)")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 0;
        }
    // Query for editing schedule          
    }elseif (isset($conn) && isset($_POST["try_edit_schedule"])){
        $id_schedule = intval($_POST["id_schedule"]);
        $user_schedule = intval($_POST["add_user_schedule"]);
        $subject_schedule = intval($_POST["add_subject_schedule"]);
        $instance_schedule = intval($_POST["add_instance_schedule"]);
        $term_schedule = intval($_POST["add_term_schedule"]);
        $course_schedule = explode("-", strval($_POST["add_month_schedule"]));
        $active = intval($_POST["add_active"]);
        $id_instance = intval(mysqli_fetch_array(mysqli_query($conn, "SELECT id_instance FROM schedule WHERE id=$id_schedule"), MYSQLI_ASSOC)["id_instance"]);
        if(mysqli_query($conn, "UPDATE schedule SET id_user=$user_schedule, id_subject=$subject_schedule, active=$active WHERE id=$id_schedule")){
            if(mysqli_query($conn, "UPDATE instance SET instance=$instance_schedule, term=$term_schedule, month=$course_schedule[1], year=$course_schedule[0] WHERE id=$id_instance")){
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 0;
        }

    // Query for inactive schedule          
    }elseif (isset($conn) && isset($_POST["try_inactive_schedule"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_schedule"]);
        for($i=0; $i<count($vet_id); $i++){
            if(!mysqli_query($conn, "UPDATE schedule SET active=0 WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for delete schedule            
    }elseif (isset($conn) && isset($_POST["try_delete_schedule"])){
        $check = 1;
        $vet_id = explode(",", $_POST["id_schedule"]);
        for($i=0; $i<count($vet_id); $i++){
            $id_instance = intval(mysqli_fetch_array(mysqli_query($conn, "SELECT id_instance FROM schedule WHERE id=$vet_id[$i]"), MYSQLI_ASSOC)["id_instance"]);
            if(!mysqli_query($conn, "DELETE FROM instance WHERE id=$id_instance")){
                $check = 0;
            }
            if(!mysqli_query($conn, "DELETE FROM schedule WHERE id=$vet_id[$i]")){
                $check = 0;
            }
        }
        echo $check;

    // Query for modifying password updating.         
    }elseif (isset($conn) && isset($_POST["try_modify_psw"])){
        if($_SESSION["psw"] == $_POST["old_psw"]){
            if(mysqli_query($conn, "UPDATE user SET psw='$_POST[new_psw]' WHERE id=$_SESSION[id]")){
                $_SESSION["psw"] = $_POST['new_psw'];
                echo 1;
            }else{
                echo 0;
            }
        }else{
            echo 2;
        }
        
      // Query for modifying recommendations.         
    }elseif (isset($conn) && isset($_POST["try_modify_recommendation"])){
        $id_user = intval($_POST["id_user"]);
        $expertise = strtolower($_POST["expertise"]);
        $supported = intval($_POST["supported"]);
        $recommendation = mysqli_real_escape_string($conn, $_POST["recommendation"]);
        if(mysqli_query($conn, "UPDATE more_info SET expertise='$expertise', supported=$supported, recommendation='$recommendation' WHERE id_user=$id_user")){
            echo 1;
        }else{
            echo 0;
        }
    }

?>