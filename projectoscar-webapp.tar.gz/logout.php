<?php

    /* 
        Author: Charlie Isaac.
        Student ID: 20220376.

        Author: John Sims.
        Student ID: 20224767.

        Description: This file contains the web applications user logout page.
    */

// LOGOUT USER SESSIONS from web application. 

    // Start session.
    session_start();

    // Clears user session id so that they cannot access logged-in pages. 
    session_unset(); // function frees all session variables currently registered.
    session_destroy(); // Destroys all data registered to a session.
    session_write_close(); // close the old and new sessions.

    // Expire the cookie to delete the session ID
    setcookie(session_name(), '', time()-3600, '/');

    // changes the session id on each log in.
    session_regenerate_id(true); 

    /* The cache-control header will instruct the browser not to cache the page, 
    and the expires header will set the date to 0, effectively expiring the page immediately. 
    This way, the user will not be able to access the previous page using the browser's back button or by clicking on a bookmarked page. */
    header("Cache-Control: no-cache, no-store, must-revalidate");
    header("Expires: Thu, 01 Jan 1970 00:00:00 GMT");
    header("location: index.php");
    exit;

?>
