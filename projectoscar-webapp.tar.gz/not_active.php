<!doctype html>
<html lang="en" class="h-100">
  
<!-- NON ACTIVE USER NOTIFICATION WHEN TRYING TO LOGIN  -->

  <!-- Header Content Section -->
  <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta name="description" content="">

      <!-- Icon for favicon (bookmark) logo  -->
      <link rel="icon" type="image/x-icon" href="img/logo.png">
      
      <!-- Page Title Top Browser / Tab --> 
      <title>Account Not Active</title>

    <!-- Bootstrap css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <!-- Custom styles for this template -->
    <link href="css/sticky-footer.css" rel="stylesheet">
    <link href="css/extras.css" rel="stylesheet">

  </head>

  <!-- HTML BODY - Where content appears --> 
  <body class="d-flex flex-column h-100">
    
    <!-- Begin page content -->
    <main class="flex-shrink-0">
        <div class="container">

          <h1 class="mt-5">This account is not active</h1>

          <p class="lead">Please verify your account or contact the Admin</p>

          <p>Back to <a href="index.php">login</a> .</p>
      </div>
    </main>

      <!-- Footer Content -->
      <footer class="footer mt-auto py-3 bg-light">
        <div class="container">
          <span class="text-muted">If you need more support contact the manager</span>
        </div>
      </footer>

  </body>
</html>
