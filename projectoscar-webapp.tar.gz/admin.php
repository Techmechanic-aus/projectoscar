<?php
    // User Session ID for access to admin.php  
    session_start();

    // Include configuration file     
    include "config.php";
    
    // Check if database connection is set     
    if(empty($_SESSION["id"]) || $_SESSION["id_role"] != 2){
        header("location: index.php");
    }
?>

<!-- ADMIN MAIN PAGE SETTINGS  -->

<!-- HTML - Header and Body Sections -->
<!doctype html>
<html lang="en">

    <!-- Header Content Section -->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">

        <!-- Icon for favicon (bookmark) logo  -->
        <link rel="icon" type="image/x-icon" href="img/logo.png">

       <!-- Page Title Top Browser / Tab -->        
        <title>Diasko | Staff Scheduler - Admin</title>

        <!-- JQuery library  -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <!-- JQuery Scripts for php page functions  -->
        <script src="js/admin.js"></script>

         <!-- Bootstrap css - readable version --> 
        <link href="css/bootstrap.css" rel="stylesheet">

        <!-- Custom styles for this template -->
        <link href="css/flexbox.css" rel="stylesheet">
        <link href="css/table.css" rel="stylesheet">
        <link href="css/font.css" rel="stylesheet">
        <link href="css/admin.css" rel="stylesheet">
        <link href="css/headers.css" rel="stylesheet">
        <link href="css/modals.css" rel="stylesheet">
        <link href="css/loading.css" rel="stylesheet">
        <link href="css/extras.css" rel="stylesheet">

    </head>

    <!-- HTML BODY - Where content appears -->
      <!-- Body - Class CSS --> 
    <body class="container-fluid">
        <div class="black_shadow center_col">
            <div class="show"></div>
        </div>

        <!-- Loading Spinnng Icon when switching .php pages -->
        <div class="loading">
            <div class="max_width max_height center_col">
                <img src="img/loading.svg" style="width: 80px;">
            </div>
        </div>

        <!-- Top bar section of Web app  -->
        <div class="row" style="height: 10%;">
            <div class="col" style="padding: 0;">
                <header id="top_bar" class="d-flex justify-content-left py-3">
                    <span class="style2">&nbsp;&nbsp;Staff Scheduler - <span id="current_path">Admin Dashboard</span></span>
                </header>
            </div>
        </div>

        <!-- Navbar Drop down menu.  -->
        <?php
            include "admin/menu_bar.php";
        ?>

        <div id="admin_show" class="row center_row">
           <script>select_menu(0)</script>
        </div>

    </body>

</html>
