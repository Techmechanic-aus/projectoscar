<?php
    // Start session
    session_start();

    // Include configuration file  
    include "../config.php";

    // Check if database connection and edit_subject parameter are set
    if (isset($conn) && isset($_POST["edit_subject"])){

    // Sanitize the input to ensure it's an integer value.    
    $id_subject = intval($_POST["id_subject"]);

    // Fetching data of the subject to be edited from the database using the id_subject
    $sql = mysqli_query($conn, "SELECT name, code, active FROM subject WHERE id=$id_subject");
    
    // Fetching the result in associative array format
    $subject = mysqli_fetch_array($sql, MYSQLI_ASSOC);

    // Display table container       
    echo "<div class='row container_table'>";
?>

   <!--Start of form elements-->  
    <div class="col-md-7 col-lg-8 max_width center_col">
        <form class="needs-validation eighty_width" novalidate>
            <div class="row g-3">

                <!-- Form Element - Subject select dropdown -->   
                <div class="col-sm-6">
                    <label for="subject_add" class="form-label">Subject</label>
                    <input type="text" class="form-control" id="subject_add" placeholder="Subject name" value="<?php echo $subject['name'];?>" required>
                </div>

                <!-- Form Element - Active select dropdown -->
                <div class="col-sm-6">
                    <label for="subject_active" class="form-label">Active</label>
                    <select id="subject_active" class="form-control" required>
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                    <?php echo "<script>$('#subject_active').val($subject[active])</script>";?>
                </div>

                <!-- Form Element - select Subject Code dropdown -->                
                <div class="col-sm-12">
                    <label for="subject_code" class="form-label">Code</label>
                    <input class="form-control" id="subject_code" placeholder="Code of the subject" required value="<?php echo $subject['code'];?>">
                </div>
            </div>
        </form>
    </div>

<!-- Add buttons and script to bottom of page  --> 
<?php
    // Close the first row table container
    echo "</div>";

    // Create a new row for the SAVE and CANCEL buttons  
    echo "<div class='row' style='height: 10%;'>";

    // Save button
    echo "<div class='col-6 end_row'>";
    echo "<button class='btn_base btn_save' onclick='try_edit_subject($id_subject)'>SAVE</button>";
    echo "</div>";

    // Cancel button   
    echo "<div class='col-6 start_row'>";
    echo "<button class='btn_base btn_cancel' onclick='cancel(4)'>CANCEL</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";

     // Set the current path in the script    
    echo "<script>set_current_path('Edit Subject')</script>";
    }

?>