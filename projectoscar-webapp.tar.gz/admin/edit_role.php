<?php
    // Start session
    session_start();

    // Include configuration file 
    include "../config.php";

    // Check if database connection and add_role parameter are set
    if (isset($conn) && isset($_POST["edit_role"])){

    // Sanitize the input to ensure it's an integer value.
    $id_role = intval($_POST["id_role"]);

    // Retrieve qualification data from database based on the given role ID.
    $sql = mysqli_query($conn, "SELECT name, description, active FROM role WHERE id=$id_role");

    // Fetch the result from the query and store it in an associative array
    $role = mysqli_fetch_array($sql, MYSQLI_ASSOC);

     // Display table container      
    echo "<div class='row container_table'>";
?>

   <!--Start of form elements-->   
    <div class="col-md-7 col-lg-8 max_width center_col">
        <form class="needs-validation eighty_width" novalidate>
            <div class="row g-3">

                <!-- Form Element - Role select dropdown -->              
                <div class="col-sm-6">
                    <label for="role_add" class="form-label">Role</label>
                    <input type="text" class="form-control" id="role_add" placeholder="Role type" value="<?php echo $role['name'];?>" required>
                </div>

                <!-- Form Element - Active select dropdown -->
                <div class="col-sm-6">
                    <label for="role_active" class="form-label">Active</label>
                    <select id="role_active" class="form-control" required>
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                    <?php echo "<script>$('#role_active').val($role[active])</script>";?>
                </div>

                <!-- Form Element - Description input field -->
                <div class="col-sm-12">
                    <label for="role_description" class="form-label">Description</label>
                    <textarea class="form-control" id="role_description" placeholder="Description of the role" style="resize: none; height: 300px;" required><?php echo $role['description'];?></textarea>
                </div>
            </div>
        </form>
    </div>

    <!-- Add buttons and script to bottom of page  -->      
    <?php
        // Close the first row table container
        echo "</div>";

        // Create a new row for the SAVE and CANCEL buttons  
        echo "<div class='row' style='height: 10%;'>";

        // Save button
        echo "<div class='col-6 end_row'>";
        echo "<button class='btn_base btn_save' onclick='try_edit_role($id_role)'>SAVE</button>";
        echo "</div>";

        // Cancel button   
        echo "<div class='col-6 start_row'>";
        echo "<button class='btn_base btn_cancel' onclick='cancel(3)'>CANCEL</button>";
        echo "</div>";

        // Close the button row 
        echo "</div>";

         // Set the current path in the script   
        echo "<script>set_current_path('Edit Role')</script>";
        }
    ?>