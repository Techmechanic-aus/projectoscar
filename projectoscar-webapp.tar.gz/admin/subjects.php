<?php
    // Start session     
    session_start();

    // Include configuration file    
    include "../config.php";

    //check if the connection is set and add_user is set
    if(isset($conn) && isset($_POST["subjects"])){
        
    echo "<script>clear_subject_array();</script>";

    // Create a variable key to be used in SQL query     
    $key = "WHERE id!=3";

    // Check if $_POST["key"] is set
    if(isset($_POST["key"])){

        // mysqli_real_escape_string() to prevent SQL injection
        $value = mysqli_real_escape_string($conn, $_POST["key"]);

        // Append to the key variable to filter the SQL query
        $key .= " AND (name LIKE('%$value%') OR code LIKE('%$value%'))";
    }

    // Perform SQL query to retrieve subject from database
    $sql = mysqli_query($conn, "SELECT id, name, code, active FROM subject $key");

    // This PHP code block generates an HTML table with subject and their details. 
    // It also includes a search bar to filter the subject displayed in the table   
    echo "<div class='row container_table' style='height: 80%'>";
    echo "<div class='col-md-4'></div>";
    echo "<div class='col-md-4 start_row' style='padding-bottom: 5px; height: 10%;'>";
    echo "<input id='key_search' class='form-control' type='search' placeholder='Search Subject'>";
    echo "<label for='key_search' style='cursor: pointer;' onclick='search_subject()'><img src='img/search.svg' style='margin-left: 16px; width: 20px;'></label>";
    echo "</div>";
    echo "<div class='col-md-4'></div>";
    echo "<div class='col-md-12' style='height: 90%; max-height: 500px; overflow: auto;'>";
    echo "<table class='max_width table style5'>";
    echo "<tr class='index_table'>";
    echo "<td style='padding: 10px 0;'>";
    echo "<span>Select</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>SubjectID</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Code</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Subject</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Active</span>";
    echo "</td>";
    echo "</tr>";

    // Initialize a counter to alternate the background color of the table rows.
    $i = 0;

    // Loop through each subject record in the database query result.
    while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){

        // Set background color of each row alternatively.         
        $color = "#fff";
        if($i%2 != 0){
            $color = "#F5F5F5FF";
        }
        $i++;

        // Output the table row for each record.
        echo "<tr class='record_table' style='background-color: $color;'>";
        echo "<td style='padding: 10px 0;'>";

        // Output a checkbox in the first cell of the row. 
        echo "<input type='checkbox' onchange='select_subject($vet[id])'>";
        echo "</td>";

        // Output the subject ID in the second cell of the row.
        echo "<td>";
        echo "<span>$vet[id]</span>";
        echo "</td>";

        // Output the subject code in the third cell of the row.
        echo "<td>";
        echo "<span>$vet[code]</span>";
        echo "</td>";

        // Output the subject name in the cell of the row.
        echo "<td>";
        echo "<span>$vet[name]</span>";
        echo "</td>";

        // Output whether the subject is active or not in the cell of the row.
        echo "<td>";
        $active = "No";
        if($vet['active'] == 1){
            $active = "Yes";
        }
        echo "<span>$active</span>";
        echo "</td>";
        
        // Close the table row for the current record.
        echo "</tr>";
    }

    // Close the table and div elements for the records section.
    echo "</table>";
    echo "</div>";
    echo "</div>";

    // Add buttons and script to bottom of page 
    echo "<div class='myTable' >"; // Aligns bottom buttons to center and width alignment shorter.
    echo "<div class='row' style='height: 4%;'>";
    echo "<div class='col-md-2 center_row'>";
    
     // Add button bottom of page   
    echo "<button class='btn_base btn_add' onclick='add_subject()'>ADD</button>";
    echo "</div>";

    // edit subject button bottom of page  
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_edit' onclick='edit_subject()'>EDIT</button>";
    echo "</div>";

    // delete subject button bottom of page 
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_red' onclick='delete_subject()'>DELETE</button>";
    echo "</div>";

    // mark inactive subject button bottom of page 
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_red' onclick='mark_inactive_subject()'>MARK INACTIVE</button>";
    echo "</div>";

    // previous page button bottom of page 
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_grey' onclick='cancel(0)'>PREVIOUS PAGE</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";

    // Set the current path in the script   
    echo "<script>set_current_path('Subjects')</script>";
    }
?>