<?php
     // Start session   
    session_start();

    // Include configuration file     
    include "../config.php";

    //check if the connection is set and add_user is set
    if(isset($conn) && isset($_POST["reset_psw"])){

   // Sanitize the input to ensure it's an integer value.
    $id_user = intval($_POST["id_account"]);
    ?>

    <!-- Modal dialog box for resetting the password -->
    <div class="modal modal-sheet position-static d-block py-5" tabindex="-1" role="dialog" id="modalSheet">
        <!-- Modal dialog -->
        <div class="modal-dialog" role="document">

            <!-- Modal content -->
            <div class="modal-content rounded-4 shadow">

                <!-- Modal header -->
                <div class="modal-header border-bottom-0">
                    <h1 class="modal-title fs-5">Password reset</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close" onclick="cancel(2)"></button>
                </div>

                <!-- Modal body -->
                <div class="modal-body py-0 center_col">
                    <input type="text" class="form-control" id="new_psw" placeholder="New password" value="" required>
                    <div style="height: 4px;"></div>
                    <input type="text" class="form-control" id="check_new_psw" placeholder="Repeat password" value="" required>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer flex-column border-top-0">
                    <button type="button" class="btn btn-lg btn-primary w-100 mx-0 mb-2" onclick="try_reset_psw(<?php echo $id_user;?>)">Save changes</button>
                    <button type="button" class="btn btn-lg btn-light w-100 mx-0" data-bs-dismiss="modal" onclick="cancel(2)">Close</button>
                </div>
            </div>
        </div>
    </div>
<?php
}