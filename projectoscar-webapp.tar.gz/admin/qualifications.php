<?php
    // Start session
    session_start();

    // Include configuration file   
    include "../config.php";

    //check if the connection is set and add_user is set
    if(isset($conn) && isset($_POST["qualifications"])){

    echo "<script>clear_qualification_array();</script>";

    // Create a variable key to be used in SQL query
    $key = "WHERE id!=3";

    // Check if $_POST["key"] is set
    if(isset($_POST["key"])){

        // mysqli_real_escape_string() to prevent SQL injection
        $value = mysqli_real_escape_string($conn, $_POST["key"]);

        // Append to the key variable to filter the SQL query
        $key .= " AND (name LIKE('%$value%') OR description LIKE('%$value%'))";
    }

    // Perform SQL query to retrieve qualifications from database
    $sql = mysqli_query($conn, "SELECT id, name, description, active FROM qualification $key");

    // This PHP code block generates an HTML table with qualifications and their details, as well as buttons to add, edit, delete, and mark inactive qualifications.
    // It also includes a search bar to filter the qualifications displayed in the table.
    echo "<div class='row container_table' style='height: 80%'>";
    echo "<div class='col-md-4'></div>";
    echo "<div class='col-md-4 start_row' style='padding-bottom: 5px; height: 10%;'>";
    echo "<input id='key_search' class='form-control' type='search' placeholder='Search Qualification'>";
    echo "<label for='key_search' style='cursor: pointer;' onclick='search_qualification()'><img src='img/search.svg' style='margin-left: 16px; width: 20px;'></label>";
    echo "</div>";
    echo "<div class='col-md-4'></div>";
    echo "<div class='col-md-12' style='height: 90%; max-height: 500px; overflow: auto;'>";
    echo "<table class='max_width table style5'>";
    echo "<tr class='index_table'>";
    echo "<td style='padding: 10px 0;'>";
    echo "<span>Select</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>QualificationID</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Qualification</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Description</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Active</span>";
    echo "</td>";
    echo "</tr>";

     // Initialize a counter to alternate the background color of the table rows.
    $i = 0;

    // Loop through each qualification record in the database query result.
    while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
        // Set background color of each row alternatively.
        $color = "#fff";
        if($i%2 != 0){
            $color = "#F5F5F5FF";
        }
        $i++;

        // Output the table row for each record.
        echo "<tr class='record_table' style='background-color: $color;'>";

        // Output a checkbox in the first cell of the row.
        echo "<td style='padding: 10px 0;'>";
        echo "<input type='checkbox' onchange='select_qualification($vet[id])'>";
        echo "</td>";

        // Output the qualification ID in the second cell of the row.
        echo "<td>";
        echo "<span>$vet[id]</span>";
        echo "</td>";

        // Output the qualification name in the third cell of the row.
        echo "<td>";
        echo "<span>$vet[name]</span>";
        echo "</td>";

        // Output the qualification description in the fourth cell of the row.
        echo "<td style='width: 500px;'>";
        $description = mysqli_real_escape_string($conn, $vet['description']);
        echo "<div style='max-height: 80px; max-width: 500px; overflow: auto;'><span>$description</span></div>";
        echo "</td>";

        // Output whether the qualification is active or not in the fifth cell of the row.
        echo "<td>";
        $active = "No";
        if($vet['active'] == 1){
            $active = "Yes";
        }
        echo "<span>$active</span>";
        echo "</td>";

        // Close the table row for the current record.
        echo "</tr>";
    }

    // Close the table and div elements for the records section.
    echo "</table>";
    echo "</div>";
    echo "</div>";

    // Add buttons and script to bottom of page   
    echo "<div class='myTable' >"; // Aligns bottom buttons to center and width alignment shorter.   
    echo "<div class='row' style='height: 4%;'>";
    echo "<div class='col-md-2 center_row'>";

    // Add button bottom of page 
    echo "<button class='btn_base btn_add' onclick='add_qualification()'>ADD</button>";
    echo "</div>";

    // edit qualification button bottom of page     
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_edit' onclick='edit_qualification()'>EDIT</button>";
    echo "</div>";

    // delete qualification button bottom of page       
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_red' onclick='delete_qualification()'>DELETE</button>";
    echo "</div>";

    // mark inactive qualification button bottom of page    
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_red' onclick='mark_inactive_qualification()'>MARK INACTIVE</button>";
    echo "</div>";

    // previous page button bottom of page 
    echo "<div class='col-md-2 center_row'>";
    echo "<button class='btn_base btn_grey' onclick='cancel(0)'>PREVIOUS PAGE</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";
    // Set the current path in the script     
    echo "<script>set_current_path('Qualifications')</script>";
    }
?>