<?php
    // Start session
    session_start();

    // Include configuration file     
    include "../config.php";

    // Check if database connection and edit_schedule parameter are set
    if (isset($conn) && isset($_POST["edit_schedule"])){

    // Sanitize the input to ensure it's an integer value.
    $id_schedule = intval($_POST["id_schedule"]);

    // Fetch schedule data based on the given id_schedule
    $schedule = mysqli_fetch_array(mysqli_query($conn, "SELECT id, id_user, id_subject, id_instance, active FROM schedule WHERE id=$id_schedule"), MYSQLI_ASSOC);
    
    // Fetch instance data based on the id_instance from schedule data
    $instance = mysqli_fetch_array(mysqli_query($conn, "SELECT id, instance, term, month, year FROM instance WHERE id=$schedule[id_instance]"), MYSQLI_ASSOC);
    
    // Fetch user data for dropdown menu
    $sql_user = mysqli_query($conn, "SELECT id, first_name, last_name, load_user FROM user WHERE id NOT IN (1, 2)");
    
    // Fetch subject data for dropdown menu
    $sql_subject = mysqli_query($conn, "SELECT id, code, name FROM subject WHERE id!=3");
    
    // Display table container      
    echo "<div class='row container_table'>";
?>

   <!--Start of form elements-->   
    <div class="col-md-7 col-lg-8 max_width center_col">
        <form class="needs-validation eighty_width" novalidate>
            <div class="row g-3">

                <!-- Form Element - User select dropdown -->   
                <div class="col-sm-6">
                    <label for="add_user_schedule" class="form-label">User</label>
                    <select class="form-control" id="add_user_schedule" required>
                        <?php
                            // Loop through users and display as options in dropdown                   
                            while($vet = mysqli_fetch_array($sql_user, MYSQLI_ASSOC)){
                                $name = ucfirst(strtolower($vet['first_name']));
                                $surname = ucfirst(strtolower($vet['last_name']));
                                $load = ucfirst(strtolower($vet['load_user']));
                                $option_text = "$name $surname [ id: $vet[id] ] [ load: $vet[load_user] ]";

                                // Add warning for overloaded users    
                                if ($load >= 2.2) {
                                $option_text .= " (WARNING: OVER LOADED)";
                                echo "<option value='$vet[id]' data-load='$vet[load_user]' style='color: red;'>$option_text</option>";
                                } else {
                                echo "<option value='$vet[id]' data-load='$vet[load_user]'>$option_text</option>";
                                }
                            }
                        ?>
                    </select>
                    <?php echo "<script>$('#add_user_schedule').val($schedule[id_user])</script>";?>
                </div>
                
                <!-- Form Element - Subject select dropdown -->
                <div class="col-sm-6">
                    <label for="add_subject_schedule" class="form-label">Subject</label>
                    <select class="form-control" id="add_subject_schedule" required>
                        <?php
                        // Loop through subjects and display as options in dropdown                        
                        while($vet = mysqli_fetch_array($sql_subject, MYSQLI_ASSOC)){
                            $name = ucfirst(strtolower($vet['name']));
                            echo "<option value='$vet[id]'>$name [ code: $vet[code] ]</option>";
                        }
                        ?>
                    </select>
                    <?php echo "<script>$('#add_subject_schedule').val($schedule[id_subject])</script>";?>
                </div>

                <!-- Form Element - Instance input field -->    
                <div class="col-sm-6">
                    <label for="add_instance_schedule" class="form-label">Instance</label>
                    <input type="number" class="form-control" id="add_instance_schedule" placeholder="" value="<?php echo $instance['instance']?>" min="1" required>
                </div>

                <!-- Form Element - Term input field -->
                <div class="col-sm-6">
                    <label for="add_term_schedule" class="form-label">Term</label>
                    <input type="number" class="form-control" id="add_term_schedule" placeholder="" value="<?php echo $instance['term']?>" min="1" required>
                </div>

                <!-- Form Element - Course Month/Year input field -->
                <div class="col-sm-6">
                    <label for="add_month_schedule" class="form-label">Course Month/Year</label>
                    <input type="month" class="form-control" id="add_month_schedule" placeholder="040045124" value="<?php echo $instance['year']."-".sprintf("%02d", $instance['month'])?>" required>
                </div>

                <!-- Form Element - Active select dropdown -->
                <div class="col-sm-6">
                    <label for="add_active" class="form-label">Active</label>
                    <select id="add_active" class="form-control" required>
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                    <?php echo "<script>$('#add_active').val($schedule[active])</script>";?>
                </div>
            </div>
        </form>
    </div>

<!-- Add buttons and script to bottom of page  --> 
<?php
    // Close the first row table container
    echo "</div>";

    // Create a new row for the SAVE and CANCEL buttons  
    echo "<div class='row' style='height: 10%;'>";

    // Save button
    echo "<div class='col-6 end_row'>";
    echo "<button class='btn_base btn_save' onclick='try_edit_schedule($id_schedule)'>SAVE</button>";
    echo "</div>";

    // Cancel button   
    echo "<div class='col-6 start_row'>";
    echo "<button class='btn_base btn_cancel' onclick='cancel(6)'>CANCEL</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";
    
    // Set the current path in the script          
    echo "<script>set_current_path('Edit Schedule')</script>";
    }
?>