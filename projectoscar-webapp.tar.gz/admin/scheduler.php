<?php
    // Start session  
    session_start();

    // Include configuration file
    include "../config.php";

    //check if the connection is set and add_user is set
    if(isset($conn) && isset($_POST["scheduler"])){

    // Create a variable key to be used in SQL query  
    $key = "";

    // Check if $_POST["key"] is set
    if(isset($_POST["key"])){

        // mysqli_real_escape_string() to prevent SQL injection
        $value = mysqli_real_escape_string($conn, $_POST["key"]);

        // Append to the key variable to filter the SQL query 
        $key .= "AND (user.first_name LIKE('%$value%') OR user.last_name LIKE('%$value%') OR user.load_user LIKE('%$value%') OR subject.code LIKE('%$value%') OR subject.name LIKE('%$value%') OR instance.instance LIKE('%$value%') OR instance.term LIKE('%$value%') OR instance.year LIKE('%$value%'))";
    }
    
    // add the condition to filter not to show user.id=3
    $key .= " AND user.id != 3";
    
    // add the condition to filter not to show "Active" schedules.
    $key .= " AND schedule.active = 1";

    // Perform SQL query to retrieve Schedule from database
    $sql = mysqli_query($conn, "SELECT schedule.id AS id, id_user, id_subject, id_instance, schedule.active AS active FROM schedule, subject, instance, user WHERE schedule.id_user=user.id AND schedule.id_subject=subject.id AND schedule.id_instance=instance.id $key ORDER BY instance.month, instance.year ASC");
    
    // This PHP code block generates an HTML table with Schedule and their details. 
    // It also includes a search bar to filter the Schedule displayed in the table   
    echo "<div class='row container_table' style='height: 80%'>";
    echo "<div class='col-md-4'></div>";
    echo "<div class='col-md-4 start_row' style='padding-bottom: 5px; height: 10%;'>";
    echo "<input id='key_search' class='form-control' type='search' placeholder='Search Filter Scheduler database here'>";
    echo "<label for='key_search' style='cursor: pointer;' onclick='search_schedule2()'><img src='img/search.svg' style='margin-left: 16px; width: 20px;'></label>";
    echo "</div>";
    echo "<div class='col-md-4'></div>";
    echo "<div class='col-md-12' style='height: 90%; max-height: 500px; overflow: auto;'>";
    echo "<table class='max_width table style5'>";
    echo "<tr class='index_table'>";
    echo "<td style='padding: 10px 0;'>";
    echo "<span>ScheduleID</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>UserID</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>User Name</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Load</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Subject Code</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Subject Name</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Instance</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Term</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Course Month</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Course Year</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Active</span>";
    echo "</td>";
    echo "</tr>";

    // Initialize a counter to alternate the background color of the table rows.
    $i = 0;

    // Loop through each schedule record in the database query result.
    while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
        $user = mysqli_fetch_array(mysqli_query($conn, "SELECT id, first_name, last_name, load_user FROM user WHERE id=$vet[id_user]"), MYSQLI_ASSOC);
        $subject = mysqli_fetch_array(mysqli_query($conn, "SELECT id, name, code FROM subject WHERE id=$vet[id_subject]"), MYSQLI_ASSOC);
        $instance = mysqli_fetch_array(mysqli_query($conn, "SELECT id, instance, term, month, year FROM instance WHERE id=$vet[id_instance]"), MYSQLI_ASSOC);
        
        // Set background color of each row alternatively.        
        $color = "#fff";
        if($i%2 != 0){
            $color = "#F5F5F5FF";
        }
        $i++;

        // Output the table row for each record.
        echo "<tr class='record_table' style='background-color: $color;'>";

        // Output the Schedule ID in the cell of the row.
        echo "<td style='padding: 10px 0;'>";
        echo "<span>$vet[id]</span>";
        echo "</td>";

        // Output the user id in the ell of the row.        
        echo "<td>";
        echo "<span>$vet[id_user]</span>";
        echo "</td>";

        // Output the first and last name in the cell of the row.
        echo "<td>";
        $name = ucfirst(strtolower($user['first_name']))." ".ucfirst(strtolower($user['last_name']));
        echo "<span>$name</span>";
        echo "</td>";

        // Output the user load in the cell of the row.
        echo "<td>";
        echo "<span>$user[load_user]</span>";
        echo "</td>";

        // Output the subject code in the cell of the row.
        echo "<td>";
        echo "<span>$subject[code]</span>";
        echo "</td>";

        // Output the subject name in the cell of the row.
        echo "<td>";
        echo "<span>$subject[name]</span>";
        echo "</td>";

        // Output the instance in the cell of the row.
        echo "<td>";
        echo "<span>$instance[instance]</span>";
        echo "</td>";

        // Output the term in the cell of the row.
        echo "<td>";
        echo "<span>$instance[term]</span>";
        echo "</td>";

        // Output the month in the cell of the row.
        echo "<td>";
        $dateObj   = DateTime::createFromFormat('!m', $instance['month']);
        $monthName = $dateObj->format('F');
        echo "<span>$monthName</span>";
        echo "</td>";

        // Output the year in the cell of the row.
        echo "<td>";
        echo "<span>$instance[year]</span>";
        echo "</td>";

        // Output whether the scheduler is active or not in the cell of the row
        echo "<td>";
        $active = "No";
        if($vet['active'] == 1){
            $active = "Yes";
        }
        echo "<span>$active</span>";
        echo "</td>";

        // Close the table row for the current record.
        echo "</tr>";
    }

    // Close the table and div elements for the records section.  
    echo "</table>";
    echo "</div>";
    echo "</div>";

    // Add buttons and script to bottom of page     
    echo "<div class='myTable' >"; // Aligns bottom buttons to center and width alignment shorter.
    echo "<div class='row' style='height: 4%;'>";
    echo "<div class='col-md-12 center_row'>";

    // previous page button bottom of page 
    echo "<button class='btn_base btn_grey' onclick='cancel(0)'>PREVIOUS PAGE</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";

    // Set the current path in the script  
    echo "<script>set_current_path('Schedules')</script>";
    }
?>