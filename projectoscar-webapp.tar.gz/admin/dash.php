 
<!-- ADMIN DASHBOARD Displayed on admin.php -->

<!-- This is a section for displaying buttons that represent different database sections, 
such as user profiles, schedule, roles, qualifications, and subjects. -->
<div class="row max_height myTable">

    <!-- This is a button for accessing the user profiles database section. When clicked, it calls the user_profiles_db() function. -->
    <div class="col-md-6 center_col">
        <div class="p-3 button-30 center_col style4" onclick="user_profiles_db()">USER PROFILES</div>
    </div>

    <!-- This is a button for accessing the schedule database section. When clicked, it calls the schedule_db() function. -->
    <div class="col-md-6 center_col">
        <div class="p-3 button-30 center_col style4" onclick="schedule_db()">SCHEDULE</div>
    </div>

    <!-- This is a button for accessing the roles database section. When clicked, it calls the roles_db() function. -->
    <div class="col-md-4 center_col">
        <div class="p-3 button-30 center_col style4" onclick="roles_db()">ROLES</div>
    </div>

    <!-- This is a button for accessing the qualifications database section. When clicked, it calls the qualifications_db() function. -->
    <div class="col-md-4 center_col">
        <div class="p-3 button-30 center_col style4" onclick="qualifications_db()">QUALIFICATIONS</div>
    </div>

    <!-- This is a button for accessing the subjects database section. When clicked, it calls the subjects_db() function. -->
    <div class="col-md-4 center_col">
        <div class="p-3 button-30 center_col style4" onclick="subjects_db()">SUBJECTS</div>
    </div>

</div>

<!-- This script section sets the current path to "Admin Dashboard" using the set_current_path() function. -->
<script>set_current_path("Admin Dashboard")</script>