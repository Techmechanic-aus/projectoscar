Installation procedure for web application is included in the A4 - Users Guide on page 45 
Titled "Installation and configuration of the web application files."

========================================================================================================
Installation and configuration of the web application files. (A4 - Users Guide on page 45)
========================================================================================================
For the web application to run correctly the following applications must be installed on each ec2 server. 
SSH into each instance and enter the following commands for each piece of software. 

• Apache HTTP
	-	sudo yum install httpd -y
	-	sudo systemctl start httpd
	-	sudo systemctl enable httpd

• PHP
	-	sudo yum install epel-release yum-utils -y
	-	sudo yum install http://rpms.remirepo.net/enterprise/remi-release-7.rpm -y
	-	sudo yum-config-manager --enable remi-php81 -y
	-	sudo yum update -y
	-	sudo yum install php -y
	-	sudo yum install php-fpm php-curl php-cli php-json php-mysql php-opcache php-dom php-exif php-fileinfo 
		php-zip php-mbstring php-hash php-imagick php-openssl php-pcre php-xml php-bcmath php-filter php-pear 
		php-gd php-mcrypt php-intl php-iconv php-zlib php-xmlreader -y


• MySQL Client
	-	sudo yum install mysql -y

=========================================================================================================
