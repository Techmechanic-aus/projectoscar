<?php
    // Start session
    session_start();

    // Include configuration file   
    include "../config.php";

    // Check if the database connection is set
    if(isset($conn)){

        // Set an empty key variable
        $key = "";

        // Check if a key was posted    
        if(isset($_POST["key"])){

        // Escape the key and store it in a variable
        $value = mysqli_real_escape_string($conn, $_POST["key"]);

        // Add the key to the search query
        $key .= " AND (subject.name LIKE('%$value%') OR subject.code LIKE('%$value%'))";
    }

        // add the condition to filter not to show "Active" schedules.
        $key .= " AND schedule.active = 1";

    // Query database for schedule and subject information
    $sql = mysqli_query($conn, "SELECT code, name, subject.active AS active, month, year FROM schedule,subject,instance WHERE schedule.id_subject=subject.id AND schedule.id_instance=instance.id AND schedule.id_user=$_SESSION[id] $key");
    
    // Start main container
    echo "<div class='row container_table' style='height: 80%'>";

    // Start column for search bar
    echo "<div class='col-md-2'></div>";
    echo "<div class='col-md-8 start_row' style='padding-bottom: 5px; height: 10%;'>";
    echo "<input id='key_search' class='form-control' type='search' placeholder='Search Subject'>";
    echo "<label for='key_search' style='cursor: pointer;' onclick='search_subject()'><img src='img/search.svg' style='margin-left: 16px; width: 20px;'></label>";
    echo "</div>";
    echo "<div class='col-md-2'></div>";

     // Start column for table
    echo "<div class='col-md-12'  style='height: 90%; max-height: 500px; overflow: auto;'>";
    echo "<table class='max_width table style5'>";

     // Start row for column headers
    echo "<tr class='index_table'>";
    echo "<td style='padding: 10px 0;'>";
    echo "<span>Subject</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Code</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Month</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Year</span>";
    echo "</td>";
    echo "<td>";
    echo "<span>Active</span>";
    echo "</td>";
    echo "</tr>";

    // Loop through query results to display schedule information
    $i = 0;
    while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
        $color = "#fff";
        if($i%2 != 0){
            $color = "#F5F5F5FF";
        }
        $i++;
        echo "<tr class='record_table' style='background-color: $color;'>";
        echo "<td style='padding: 10px 0;'>";
        $name = strtolower($vet['name']);
        echo "<span>$name</span>";
        echo "</td>";
        echo "<td>";
        $code = strtoupper($vet['code']);
        echo "<span>$code</span>";
        echo "</td>";
        echo "<td>";
        $dateObj   = DateTime::createFromFormat('!m', $vet['month']);
        $monthName = $dateObj->format('F');
        echo "<span>$monthName</span>";
        echo "</td>";
        echo "<td>";
        echo "<span>$vet[year]</span>";
        echo "</td>";
        echo "<td>";
        $active = "No";
        if($vet['active'] == 1){
            $active = "Yes";
        }
        echo "<span>$active</span>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
    echo "</div>";
    echo "</div>";

    
}

?>