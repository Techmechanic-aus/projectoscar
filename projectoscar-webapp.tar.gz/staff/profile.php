<?php
    // Start session
    session_start();

    // Include configuration file   
    include "../config.php";

    //check if the connection is set and add_user is set
    if (isset($conn) && isset($_POST["profile"])){
        // Get user ID from session  
        $id_user = $_SESSION["id"];

        // Query database for user data
        $sql = mysqli_query($conn, "SELECT id_role, id_qualification, first_name, last_name, birthday, phone, email, address, suburb, post_code, load_user, status, psw, active FROM user WHERE id=$id_user");
        
        // Fetch user data as an associative array        
        $user = mysqli_fetch_array($sql, MYSQLI_ASSOC);

        // Display table container           
        echo "<div class='row container_table'>";
?>

    <!--Start of form elements--> 
    <div class="col-md-7 col-lg-8 max_width center_col">
        <form class="needs-validation eighty_width" novalidate>
            <div class="row g-3">

                <!-- Form Element - User ID --> 
                <div class="col-sm-3">
                    <label for="add_last_name" class="form-label">UserID</label>
                    <input type="text" class="form-control" id="add_last_name" placeholder="" value="<?php echo $id_user;?>" disabled>
                </div>

                 <!-- Form Element - First name -->
                <div class="col-sm-3">
                    <input id="modify_id_user" type="hidden" value="<?php echo $id_user;?>">
                    <label for="add_first_name" class="form-label">First name</label>
                    <input type="text" class="form-control" id="add_first_name" placeholder="" value="<?php echo ucfirst(strtolower($user['first_name']));?>" disabled>
                </div>

                <!-- Form Element - Last name --> 
                <div class="col-sm-3">
                    <label for="add_last_name" class="form-label">Last name</label>
                    <input type="text" class="form-control" id="add_last_name" placeholder="" value="<?php echo ucfirst(strtolower($user['last_name']));?>" disabled>
                </div>

                <!-- Form Element - Email -->
                <div class="col-sm-3">
                    <label for="add_email" class="form-label">Email</label>
                    <input type="text" class="form-control" id="add_email" placeholder="email@example.com" value="<?php echo strtolower($user['email']);?>" disabled>
                </div>

                <!-- Form Element - Phone --> 
                <div class="col-sm-3">
                    <label for="add_phone" class="form-label">Phone</label>
                    <input type="text" class="form-control" id="add_phone" placeholder="040045124" value="<?php echo $user['phone'];?>" disabled>
                </div>

                <!-- Form Element - Date Of Birthday -->  
                <div class="col-sm-3">
                    <label for="add_birthday" class="form-label">Date Of Birthday</label>
                    <input type="date" class="form-control" id="add_birthday" placeholder="" value="<?php echo $user['birthday'];?>" disabled>
                </div>

                <!-- Form Element - Load displayed -->  
                <div class="col-sm-3">
                    <label for="add_load" class="form-label">Load</label>
                    <select id="add_load" class="form-control" disabled>
                        <?php
                            for($i=0; $i<=4.0; $i+=0.2){ //  Load User Value here 0 to 4 load.
                            echo "<option value='$i'>$i</option>";
                        }
                        ?>
                    </select>
                    <?php echo "<script>$('#add_load').val($user[load_user]);</script>";?>
                </div>

                <!-- Form Element - Status --> 
                <div class="col-sm-3">
                    <label for="add_status" class="form-label">Status</label>
                    <select id="add_status" class="form-control" disabled>
                        <option value="0">Part-Time</option>
                        <option value="1">Full-Time</option>
                    </select>
                    <?php echo "<script>$('#add_status').val($user[status]);</script>";?>
                </div>

                <!-- Form Element - Active --> 
                <div class="col-sm-3">
                    <label for="add_active" class="form-label">Active</label>
                    <select id="add_active" class="form-control" disabled>
                        <option value="1">Yes</option>
                        <option value="0">No</option>
                    </select>
                    <?php echo "<script>$('#add_active').val($user[active]);</script>";?>
                </div>

                <!-- Form Element - Address --> 
                <div class="col-sm-3">
                    <label for="add_address" class="form-label">Address</label>
                    <input type="text" class="form-control" id="add_address" placeholder="1234 Main St" value="<?php echo $user['address'];?>" disabled>
                </div>

                <!-- Form Element - Suburb --> 
                <div class="col-sm-3">
                    <label for="add_suburb" class="form-label">Suburb</label>
                    <input type="text" class="form-control" id="add_suburb" placeholder="Melbourne" value="<?php echo $user['suburb'];?>" disabled>
                </div>

                <!-- Form Element - Post Code -->
                <div class="col-sm-3">
                    <label for="add_postcode" class="form-label">Post Code</label>
                    <input type="text" class="form-control" id="add_postcode" placeholder="2601" value="<?php echo $user['post_code'];?>" disabled>
                </div>

                <!-- Form Element - Role --> 
                <div class="col-sm-3">
                    <label for="add_role" class="form-label">Role</label>
                    <select id="add_role" class="form-control" disabled>
                        <?php
                        // Fetches the user role from the database                         
                        $sql = mysqli_query($conn, "SELECT id, name FROM role WHERE id!=7");
                        while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
                            echo "<option value='$vet[id]'>$vet[name]</option>";
                        }
                        ?>
                    </select>

                    <!-- Sets the user's current role -->                      
                    <?php echo "<script>$('#add_role').val($user[id_role]);</script>";?>
                </div>

                <!-- Form Element - Qualification -->   
                <div class="col-sm-3">
                    <label for="add_qualification" class="form-label">Qualification</label>
                    <select id="add_qualification" class="form-control" disabled>
                        <?php
                        // Fetches the user Qualification from the database                          
                        $sql = mysqli_query($conn, "SELECT id, name FROM qualification WHERE id!=3");
                        while($vet = mysqli_fetch_array($sql, MYSQLI_ASSOC)){
                            echo "<option value='$vet[id]'>$vet[name]</option>";
                        }
                        ?>                                              
                    </select>

                    <!-- Sets the user's current Qualification -->                    
                    <?php echo "<script>$('#add_qualification').val($user[id_qualification]);</script>";?>
                </div>

                <div class="col-sm-6"></div>
                <!-- Form Element - Divider from User Details to Reset Password --> 
                <div class="col-sm-12 divider" style="width: 100%;"></div>

                <!-- Form Element -  User Reset Password - Enter Old Password input field --> 
                <div class="col-sm-3">
                    <input type="password" class="form-control" id="old_psw" placeholder="Old Password" value="" required>
                </div>

                <!-- Form Element -  User Reset Password - Enter New Password input field --> 
                <div class="col-sm-3">
                    <input type="password" class="form-control" id="new_psw" placeholder="New Password" value="" required>
                </div>

                <!-- Form Element -  User Reset Password - Enter Confirm New Password input field --> 
                <div class="col-sm-3">
                    <input type="password" class="form-control" id="confirm_psw" placeholder="Confirm Password" value="" required>
                </div>

                <!--  RESET SAVE NEW PASSWORD BUTTON ON CLICK -->                  
                <div class='col-sm-3'>
                    <div class='btn_base btn_reset_psw' onclick='try_modify_psw()'>Reset Password</div>
                </div>
            </div>
        </form>
    </div>

<!-- Add buttons and script to bottom of page  -->
<?php
    // Close the first row table container
    echo "</div>";

    // Aligns bottom buttons to center and width alignment shorter.    
    echo "<div class='myTable' >";      

    // Create a new row for the SAVE and CANCEL buttons      
    echo "<div class='row' style='height: 10%;'>";
 
    // PREVIOUS PAGE button    
    echo "<div class='col-md-12 center_row'>";
    echo "<button class='btn_base btn_grey' onclick='cancel(0)'>PREVIOUS PAGE</button>";
    echo "</div>";

    // Close the button row 
    echo "</div>";

    // Set the current path in the script 
    echo "<script>set_current_path('My Profile')</script>";
    }
?>