
<!-- STAFF DASHBOARD Displayed on Staff.php -->

<!-- This section creates a row container with a CSS class and sets its height -->
<div class="row max_height">

    <!-- This div creates a column container with a specified width -->
    <div class="col-md-12 center_col">
            <?php
            // This PHP code includes a separate file that contains subject information
            include "my_subject.php";
        ?>
    </div>
</div>

<!-- This script section calls a function and sets the current path to "Staff Dashboard" -->
<script>set_current_path("Staff Dashboard")</script>