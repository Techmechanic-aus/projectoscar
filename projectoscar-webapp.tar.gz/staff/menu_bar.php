
<!--MENU NAVIGATION BAR FOR staff.php -->

<!-- This section creates a row container with a specified height -->
<div class="row" style="height: 6%;">
    <div class="col-md-1">
    </div>

    <!-- This div creates a column container with a specified width and applies several styles to it -->
    <div class="col-md-10 space_between_row style5" style="background-color: #00796B; color: #fff; border-radius: 4px;">
        <div>

            <!-- This span creates a button with a specific ID and CSS class -->
            <span id="macro_path" class="btn_dash">Dashboard</span>
        </div>

        <!-- This div creates a row container with space between its contents -->
        <div class="space_between_row">

            <!-- This ordered list creates a button with a specified ID and onclick function -->
            <ol id="drop_btn" onclick="drop_down(0)">
                
                <!-- This div creates a button with a specific CSS class and nested content -->
                <div class="btn_dash space_between_row">
                    <il>
                        <span>Staff&nbsp;&nbsp;</span>

                        <!-- This image element sets the source for an icon -->
                        <img id="chevron_img" src="img/chevron-down.svg" class="chevron_down">
                    </il>
                </div>

                <!-- This list item creates a container for dropdown menu options with a specific CSS class -->
                <li class='center_col container_drop'>
                    <span class='btn_drop_down' onclick="select_menu(0)">Dashboard</span>
                    <span class='btn_drop_down' onclick="select_menu(1)">Scheduler</span>
                    <span class='btn_drop_down' onclick="select_menu(2)">My Profile</span>
                </li>
            </ol>

            <!-- This span creates a button with a specific CSS class and onclick function to logout user -->
            <span class="btn_dash" style="cursor: pointer;" onclick="location.href = 'logout.php'">Logout</span>
        </div>
    </div>
    <div class="col-md-1">
    </div>
</div>