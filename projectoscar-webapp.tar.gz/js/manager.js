
/* MANAGER FUNCTIONS for manager.php single page */

$(document).ready(function (){
    var window_height = $(window).height();
    $("body").css("height", window_height);
});

// LOADING Image.
function loading_gif(bool){
    if(bool){
        $(".loading").css("display", "block");
    }else{
        $(".loading").css("display", "none");
    }
}


// NAVBAR - MENUD DROP DOWN 
function select_menu(id_menu){
    loading_gif(true);
    if(id_menu == 0){
        $.post("manager/dash.php", {main: 1}, function (data){
            $("#admin_show").html(data);
            $("#macro_path").text("Dashboard");
            loading_gif(false);
        });
    }else if(id_menu == 1){
        $.post("manager/scheduler.php", {scheduler: 1}, function (data){
            $("#admin_show").html(data);
            $("#macro_path").text("Scheduler");
            loading_gif(false);
        });
    }else if(id_menu == 2){
        $.post("manager/profile.php", {profile: 1}, function (data){
            $("#admin_show").html(data);
            $("#macro_path").text("Profile");
            loading_gif(false);
        });
    }
}

// Email Function. 
function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

// Cancel Function.
function cancel(val){
    if(val == 0){
        select_menu(0);
    }else if(val == 1){
        user_profiles_db();
    }else if(val == 2){
        $(".black_shadow").css("display", "none");
    }else if(val == 3){
        roles_db();
    }else if(val == 4){
        subjects_db();
    }else if(val == 5){
        qualifications_db();
    }else if(val == 6){
        schedule_db();
    }
}

//  Displays user profiles for manager.
function user_profiles_db(){
    loading_gif(true);
    $.post("manager/user_profiles.php", {user_profiles: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

//  Displays schedule for manager.
function schedule_db(){
    loading_gif(true);
    $.post("manager/schedule.php", {schedule: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

//  Sets current path.
function set_current_path(txt){
    $("#current_path").text(txt);
}

/*USER PROFILES*/
// Variables for User Select array function.
var select_array = [];
function findValueInArray(value){
    var result = false;
    for(var i=0; i<select_array.length; i++){
        var name = select_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// Clears array. 
function clear_array(){
    select_array = [];
}

// Select User ID.
function select_user(id){
    if(findValueInArray(id)){
        var index = select_array.indexOf(id);
        if (index !== -1) {
            select_array.splice(index, 1);
        }
    }else{
        select_array.push(id);
    }
}

// ADD NEW USER function.
function add_user(){
    loading_gif(true);
    $.post("manager/add_user.php", {add_user: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Adding new user details. 
function try_add_user(){
    var first_name = $("#add_first_name").val();
    var last_name = $("#add_last_name").val();
    var email = $("#add_email").val();
    var psw = $("#add_psw").val();
    var phone = $("#add_phone").val();
    var dob = $("#add_birthday").val();
    var load = $("#add_load").val();
    var status = $("#add_status").val();
    var address = $("#add_address").val();
    var suburb = $("#add_suburb").val();
    var postcode = $("#add_postcode").val();
    var role = $("#add_role").val();
    var qualification = $("#add_qualification").val();
    var active = $("#add_active").val();
    if(first_name.trim() && last_name.trim() && email.trim() && psw.trim() && phone.trim() && dob.trim() && address.trim() && suburb.trim() && postcode.trim()){
        if(isEmail(email)){
            loading_gif(true);
            $.post("manager/query.php", {try_add_user: 1, first_name: first_name, last_name: last_name, email: email, psw: psw, phone: phone, dob: dob, load: load, status: status, address: address, suburb: suburb, postcode: postcode, role: role, qualification: qualification, active: active}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("User added!");
                    cancel(1);
                }else if(data == 2){
                    alert("This email is already present");
                }else{
                    alert("Error, try again");
                }
            });
        }else{
            alert("Please insert a valid email");
        }
    }else{
        alert("Please complete all fields");
    }
}

// Modifying / editing user details.
function try_modify_user(){
    var id_user = $("#modify_id_user").val();
    var first_name = $("#add_first_name").val();
    var last_name = $("#add_last_name").val();
    var email = $("#add_email").val();
    var psw = $("#add_psw").val();
    var phone = $("#add_phone").val();
    var dob = $("#add_birthday").val();
    var load = $("#add_load").val();
    var status = $("#add_status").val();
    var address = $("#add_address").val();
    var suburb = $("#add_suburb").val();
    var postcode = $("#add_postcode").val();
    var role = $("#add_role").val();
    var qualification = $("#add_qualification").val();
    var active = $("#add_active").val();
    if(first_name.trim() && last_name.trim() && email.trim() && psw.trim() && phone.trim() && dob.trim() && address.trim() && suburb.trim() && postcode.trim()){
        if(isEmail(email)){
            loading_gif(true);
            $.post("manager/query.php", {try_modify_user: 1, id_user: id_user, first_name: first_name, last_name: last_name, email: email, psw: psw, phone: phone, dob: dob, load: load, status: status, address: address, suburb: suburb, postcode: postcode, role: role, qualification: qualification, active: active}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("Changes applied!");
                    cancel(1);
                }else if(data == 2){
                    alert("This email is already present");
                }else{
                    alert("Error, try again");
                }
            });
        }else{
            alert("Please insert a valid email");
        }
    }else{
        alert("Please complete all fields");
    }
}

// More info button.
function more_info(id){
    loading_gif(true);
    $.post("manager/more_info.php", {more_info: 1, id_user: id}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Change year function. 
function change_year(id, val){
    var year = parseInt($("#current_year").text()) + val;
    loading_gif(true);
    $.post("manager/more_info.php", {more_info: 1, id_user: id, year: year}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

function change_year_profile(val){
    var year = parseInt($("#current_year").text()) + val;
    loading_gif(true);
    $.post("manager/user_profiles.php", {user_profiles: 1, year: year}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}
// Edit info function. 
function try_edit_more_info(id){
    var expertise = $("#staff_expertise").val();
    var supported = $("#staff_supported").val();
    var recommendation = $("#staff_rec").val();
    if(expertise.trim() && supported.trim() && recommendation.trim()){
        loading_gif(true);
        $.post("manager/query.php", {try_modify_recommendation: 1, id_user: id, expertise: expertise, supported: supported, recommendation: recommendation}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Changes applied!");
                more_info(id);
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Drop down menus to display more options. 
function drop_down(val){
    if(val == 0){
        $(".container_drop").css("display", "flex");
        $("#chevron_img").attr("src","img/chevron-up.svg");
        $("#drop_btn").attr("onclick","drop_down(1)");
    }else if(val == 1){
        $(".container_drop").css("display", "none");
        $("#chevron_img").attr("src","img/chevron-down.svg");
        $("#drop_btn").attr("onclick","drop_down(0)");
    }
}

// Search Function.
function search(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("manager/user_profiles.php", {user_profiles: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}


// Edit User Function. 
function edit_account(){
    if(select_array.length == 1){
        var id_account = select_array.toString();
        loading_gif(true);
        $.post("manager/edit_user.php", {edit_user: 1, id_account: id_account}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one account");
    }
}


/*SCHEDULE*/

// Variables for Select schedule array function. 
var select_schedule_array = [];
function findValueInSchedule(value){
    var result = false;
    for(var i=0; i<select_schedule_array.length; i++){
        var name = select_schedule_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// clears schedule array. 
function clear_schedule_array(){
    select_schedule_array = [];
}

// Selects schedule ID function. 
function select_schedule(id){
    if(findValueInSchedule(id)){
        var index = select_schedule_array.indexOf(id);
        if (index !== -1) {
            select_schedule_array.splice(index, 1);
        }
    }else{
        select_schedule_array.push(id);
    }
}

// Search Schedule function. 
function search_schedule(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("manager/schedule.php", {schedule: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Search scheduler function.
function search_schedule2(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("manager/scheduler.php", {scheduler: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Adds schedule function.
function add_schedule(){
    loading_gif(true);
    $.post("manager/add_schedule.php", {add_schedule: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Add details to schedule function. 
function try_add_schedule(){
    var add_user_schedule = $("#add_user_schedule").val();
    var add_subject_schedule = $("#add_subject_schedule").val();
    var add_instance_schedule = $("#add_instance_schedule").val();
    var add_term_schedule = $("#add_term_schedule").val();
    var add_month_schedule = $("#add_month_schedule").val();
    var add_active = $("#add_active").val();
    if(add_instance_schedule.trim() && add_term_schedule.trim() && add_month_schedule.trim()){
        loading_gif(true);
        $.post("manager/query.php", {try_add_schedule: 1, add_user_schedule: add_user_schedule, add_subject_schedule: add_subject_schedule, add_instance_schedule: add_instance_schedule, add_term_schedule: add_term_schedule, add_month_schedule: add_month_schedule, add_active: add_active}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Schedule added!");
                cancel(6);
            }else if(data == 2){
                alert("This schedule is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}


// Edits schedule Function. 
function edit_schedule(){
    if(select_schedule_array.length == 1){
        var id_schedule = select_schedule_array.toString();
        loading_gif(true);
        $.post("manager/edit_schedule.php", {edit_schedule: 1, id_schedule: id_schedule}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one schedule");
    }
}

// Edits details to schedule function.
function try_edit_schedule(id){
    var add_user_schedule = $("#add_user_schedule").val();
    var add_subject_schedule = $("#add_subject_schedule").val();
    var add_instance_schedule = $("#add_instance_schedule").val();
    var add_term_schedule = $("#add_term_schedule").val();
    var add_month_schedule = $("#add_month_schedule").val();
    var add_active = $("#add_active").val();
    if(add_instance_schedule.trim() && add_term_schedule.trim() && add_month_schedule.trim()){
        loading_gif(true);
        $.post("manager/query.php", {try_edit_schedule: 1, id_schedule: id, add_user_schedule: add_user_schedule, add_subject_schedule: add_subject_schedule, add_instance_schedule: add_instance_schedule, add_term_schedule: add_term_schedule, add_month_schedule: add_month_schedule, add_active: add_active}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Changes applied!");
                cancel(6);
            }else if(data == 2){
                alert("This schedule is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}


/*PROFILE - Displays option to modify user password to new password */
function try_modify_psw(){
    var old_psw = $("#old_psw").val();
    var new_psw = $("#new_psw").val();
    var confirm_psw = $("#confirm_psw").val();
    if(old_psw.trim() && new_psw.trim() && confirm_psw.trim()){
        if(new_psw == confirm_psw){
            loading_gif(true);
            $.post("manager/query.php", {try_modify_psw: 1, old_psw: old_psw, new_psw: new_psw}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("Your password has been changed!");
                    select_menu(2);
                }else if(data == 0){
                    alert("Error, try again");
                }else if(data == 2){
                    alert("The old password does not match!");
                }
            });
        }else{
            alert("Passwords don't match");
        }
    }else{
        alert("Please complete all fields");
    }
}

function loadScheduleTable(user_id, month, year){
    //alert(month);
    console.log('Loaded schedule table' , month);
    var key = $("#key_search").val();

    loading_gif(true);
    $.post("manager/schedule_table.php", {
        schedule: 1,
        key: key,
        user_id : user_id,
        year: year,
        month: month
    }, function (data){
        loading_gif(false);
        $("#schedule-wrapper").html(data);
    });
}
function loadScheduleTableOnProfile( month, year){
    //alert(month);
    console.log('Loaded schedule table' , month);
    var key = $("#key_search").val();

    loading_gif(true);
    $.post("manager/schedule_table.php", {
        schedule: 1,
        key: key,
        year: year,
        month: month,
        is_edit_schedule: 1,
    }, function (data){
        loading_gif(false);
        $("#schedule-wrapper").html(data);
    });
}