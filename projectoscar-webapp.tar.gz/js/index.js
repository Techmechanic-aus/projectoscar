
// LOADING Image.
function loading_gif(bool){
    if(bool){
        $(".loading").css("display", "block");
    }else{
        $(".loading").css("display", "none");
    }
}

// Email login verification function.
function try_login(){
    var email = $("#email").val();
    var psw = $("#psw").val();
    if(email.trim() && psw.trim()){
        loading_gif(true);
        $.post("query.php", {login: 1, email: email, psw: psw}, function (data){
            loading_gif(false);
            console.log(data);
            if(data == -1){
                alert("Invalid credentials");
            }else if(data == -2){
                location.href = "not_active.php";
            }else if(data == 2){
                location.href = "admin.php";
            }else if(data == 1){
                location.href = "manager.php";
            }else{
                location.href = "staff.php";
            }
        });
    }else{
        alert("Please enter your credentials");
    }
}