
/* ADMIN FUNCTIONS for admin.php single page */
$(document).ready(function (){
    var window_height = $(window).height();
    $("body").css("height", window_height);
});

// LOADING Image.
function loading_gif(bool){
    if(bool){
        $(".loading").css("display", "block");
    }else{
        $(".loading").css("display", "none");
    }
}

// Show/Hide Password function
function show_hide_psw(){
    if($('#show_hide_password input').attr("type") == "text"){
        $('#show_hide_password input').attr('type', 'password');
        $('#show_hide_password i').addClass( "fa-eye-slash" );
        $('#show_hide_password i').removeClass( "fa-eye" );
    }else if($('#show_hide_password input').attr("type") == "password"){
        $('#show_hide_password input').attr('type', 'text');
        $('#show_hide_password i').removeClass( "fa-eye-slash" );
        $('#show_hide_password i').addClass( "fa-eye" );
    }
}

// NAVBAR - MENUD DROP DOWN 
function select_menu(id_menu){
    loading_gif(true);
    if(id_menu == 0){
        $.post("admin/dash.php", {main: 1}, function (data){
            $("#admin_show").html(data);
            $("#macro_path").text("Dashboard");
            loading_gif(false);
        });
    }else if(id_menu == 1){
        $.post("admin/scheduler.php", {scheduler: 1}, function (data){
            $("#admin_show").html(data);
            $("#macro_path").text("Scheduler");
            loading_gif(false);
        });
    }else if(id_menu == 2){
        $.post("admin/profile.php", {profile: 1}, function (data){
            $("#admin_show").html(data);
            $("#macro_path").text("Profile");
            loading_gif(false);
        });
    }
}

// Email Function. 
function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
    return regex.test(email);
}

// Cancel Function.
function cancel(val){
    if(val == 0){
        select_menu(0);
    }else if(val == 1){
        user_profiles_db();
    }else if(val == 2){
        $(".black_shadow").css("display", "none");
    }else if(val == 3){
        roles_db();
    }else if(val == 4){
        subjects_db();
    }else if(val == 5){
        qualifications_db();
    }else if(val == 6){
        schedule_db();
    }
}

// User Profiles Database Database Display Function.
function user_profiles_db(){
    loading_gif(true);
    $.post("admin/user_profiles.php", {user_profiles: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Roles Database Database Display Function.
function roles_db(){
    loading_gif(true);
    $.post("admin/roles.php", {roles: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Subjects Database Database Display Function.
function subjects_db(){
    loading_gif(true);
    $.post("admin/subjects.php", {subjects: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Qualification Database Display Function.
function qualifications_db(){
    loading_gif(true);
    $.post("admin/qualifications.php", {qualifications: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Schedule Database Display Function.
function schedule_db(){
    loading_gif(true);
    $.post("admin/schedule.php", {schedule: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

//  Sets current path.
function set_current_path(txt){
    $("#current_path").text(txt);
}

/*USER PROFILES*/

// Variables for user select function 
var select_array = [];
function findValueInArray(value){
    var result = false;
    for(var i=0; i<select_array.length; i++){
        var name = select_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// Clears array.
function clear_array(){
    select_array = [];
}

// Select User ID.
function select_user(id){
    if(findValueInArray(id)){
        var index = select_array.indexOf(id);
        if (index !== -1) {
            select_array.splice(index, 1);
        }
    }else{
        select_array.push(id);
    }
}

// ADD NEW USER function.
function add_user(){
    loading_gif(true);
    $.post("admin/add_user.php", {add_user: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Adding new user details. 
function try_add_user(){
    var first_name = $("#add_first_name").val();
    var last_name = $("#add_last_name").val();
    var email = $("#add_email").val();
    var psw = $("#add_psw").val();
    var phone = $("#add_phone").val();
    var dob = $("#add_birthday").val();
    var load = $("#add_load").val();
    var status = $("#add_status").val();
    var address = $("#add_address").val();
    var suburb = $("#add_suburb").val();
    var postcode = $("#add_postcode").val();
    var role = $("#add_role").val();
    var qualification = $("#add_qualification").val();
    var active = $("#add_active").val();
    if(first_name.trim() && last_name.trim() && email.trim() && psw.trim() && phone.trim() && dob.trim() && address.trim() && suburb.trim() && postcode.trim()){
        if(isEmail(email)){
            loading_gif(true);
            $.post("admin/query.php", {try_add_user: 1, first_name: first_name, last_name: last_name, email: email, psw: psw, phone: phone, dob: dob, load: load, status: status, address: address, suburb: suburb, postcode: postcode, role: role, qualification: qualification, active: active}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("User added!");
                    cancel(1);
                }else if(data == 2){
                    alert("This email is already present");
                }else{
                    alert("Error, try again");
                }
            });
        }else{
            alert("Please insert a valid email");
        }
    }else{
        alert("Please complete all fields");
    }
}

// Modifying / editing user details.
function try_modify_user(){
    var id_user = $("#modify_id_user").val();
    var first_name = $("#add_first_name").val();
    var last_name = $("#add_last_name").val();
    var email = $("#add_email").val();
    var psw = $("#add_psw").val();
    var phone = $("#add_phone").val();
    var dob = $("#add_birthday").val();
    var load = $("#add_load").val();
    var status = $("#add_status").val();
    var address = $("#add_address").val();
    var suburb = $("#add_suburb").val();
    var postcode = $("#add_postcode").val();
    var role = $("#add_role").val();
    var qualification = $("#add_qualification").val();
    var active = $("#add_active").val();
    if(first_name.trim() && last_name.trim() && email.trim() && psw.trim() && phone.trim() && dob.trim() && address.trim() && suburb.trim() && postcode.trim()){
        if(isEmail(email)){
            loading_gif(true);
            $.post("admin/query.php", {try_modify_user: 1, id_user: id_user, first_name: first_name, last_name: last_name, email: email, psw: psw, phone: phone, dob: dob, load: load, status: status, address: address, suburb: suburb, postcode: postcode, role: role, qualification: qualification, active: active}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("Changes applied!");
                    cancel(1);
                }else if(data == 2){
                    alert("This email is already present");
                }else{
                    alert("Error, try again");
                }
            });
        }else{
            alert("Please insert a valid email");
        }
    }else{
        alert("Please complete all fields");
    }
}

// Reset Password Function.
function try_reset_psw(id){
    var new_psw = $("#new_psw").val();
    var check_new_psw = $("#check_new_psw").val();
    if(new_psw.trim() && check_new_psw.trim()){
        if(new_psw == check_new_psw){
            loading_gif(true);
            $.post("admin/query.php", {try_reset_psw: 1, id_user: id, new_psw: new_psw}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("Password reset!");
                    cancel(2);
                }else{
                    alert("Error, try again");
                }
            });
        }else{
            alert("Passwords do not match!");
        }
    }else{
        alert("Please complete all fields");
    }
}

// Drop down menus to display more options. 
function drop_down(val){
    if(val == 0){
        $(".container_drop").css("display", "flex");
        $("#chevron_img").attr("src","img/chevron-up.svg");
        $("#drop_btn").attr("onclick","drop_down(1)");
    }else if(val == 1){
        $(".container_drop").css("display", "none");
        $("#chevron_img").attr("src","img/chevron-down.svg");
        $("#drop_btn").attr("onclick","drop_down(0)");
    }
}

// Search Function.
function search(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("admin/user_profiles.php", {user_profiles: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Delete account function. 
function delete_account() {
    if (select_array.length > 0) {
        var id_account = select_array.toString();
        // Show confirmation dialog box
        if (confirm("Are you sure you want to delete the selected account(s)?")) {
            loading_gif(true);
            $.post("admin/query.php", {try_delete_user: 1, id_account: id_account}, function (data){
                loading_gif(false);
                if (data == 1) {
                    alert("The selected accounts have been deleted!");
                    user_profiles_db();
                } else if (data == 0) {
                    alert("Error deleting selected accounts");
                }
            });
        }
    } else {
        alert("Please select at least one account");
    }
}


// Make Inactive Function. 
function mark_inactive_account(){
    if(select_array.length > 0){
        var id_account = select_array.toString();
        loading_gif(true);
        $.post("admin/query.php", {try_inactive_user: 1, id_account: id_account}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("The selected accounts have been deactivated!");
                user_profiles_db();
            }else if(data == 0){
                alert("Error, try again");
            }
        });
    }else{
        alert("Please select at least one account");
    }
}

// Edit User Function. 
function edit_account(){
    if(select_array.length == 1){
        var id_account = select_array.toString();
        loading_gif(true);
        $.post("admin/edit_user.php", {edit_user: 1, id_account: id_account}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one account");
    }
}

// Reset Password Function.
function reset_psw(){
    if(select_array.length == 1){
        var id_account = select_array.toString();
        loading_gif(true);
        $.post("admin/reset_psw.php", {reset_psw: 1, id_account: id_account}, function (data){
            loading_gif(false);
            $(".show").html(data);
            $(".black_shadow").css("display", "flex");
        });
    }else{
        alert("Please select one account");
    }
}

/*ROLES*/
// Variables for Role Selects Function.
var select_role_array = [];
function findValueInRole(value){
    var result = false;
    for(var i=0; i<select_role_array.length; i++){
        var name = select_role_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// clears Role array.
function clear_role_array(){
    select_role_array = [];
}

// Selects Role.
function select_role(id){
    if(findValueInRole(id)){
        var index = select_role_array.indexOf(id);
        if (index !== -1) {
            select_role_array.splice(index, 1);
        }
    }else{
        select_role_array.push(id);
    }
}

// Search role Function.
function search_role(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("admin/roles.php", {roles: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Add Role Function.
function add_role(){
    loading_gif(true);
    $.post("admin/add_role.php", {add_role: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Add try add role function.
function try_add_role(){
    var role = $("#role_add").val();
    var role_active = $("#role_active").val();
    var role_description = $("#role_description").val();
    if(role.trim() && role_active.trim() && role_description.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_add_role: 1, role: role, role_active: role_active, role_description: role_description}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Role added!");
                cancel(3);
            }else if(data == 2){
                alert("This role is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Delete Role Function
function delete_role(){
    if(select_role_array.length > 0){
        var id_role = select_role_array.toString();
        loading_gif(true);
        // Show confirmation dialog box        
        if (confirm("Are you sure you want to delete the selected roles?")) {
            $.post("admin/query.php", {try_delete_role: 1, id_role: id_role}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("The selected roles have been deleted!");
                    roles_db();
                }else if(data == 0){
                    alert("Error deleting selected roles");
                }
            });
        } else {
            loading_gif(false);
        }
    }else{
        alert("Please select at least one role");
    }
}

// Edit Role Function.
function edit_role(){
    if(select_role_array.length == 1){
        var id_role = select_role_array.toString();
        loading_gif(true);
        $.post("admin/edit_role.php", {edit_role: 1, id_role: id_role}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one role");
    }
}

// Try edit Role Function. 
function try_edit_role(id){
    var role = $("#role_add").val();
    var role_active = $("#role_active").val();
    var role_description = $("#role_description").val();
    if(role.trim() && role_active.trim() && role_description.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_edit_role: 1, id_role: id, role: role, role_active: role_active, role_description: role_description}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Changes applied!");
                cancel(3);
            }else if(data == 2){
                alert("This role is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Mark inactive Role Function.
function mark_inactive_role(){
    if(select_role_array.length > 0){
        var id_role = select_role_array.toString();
        loading_gif(true);
        $.post("admin/query.php", {try_inactive_role: 1, id_role: id_role}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("The selected roles have been deactivated!");
                roles_db();
            }else if(data == 0){
                alert("Error, try again");
            }
        });
    }else{
        alert("Please select at least one role");
    }
}

/*SUBJECTS*/
// Variables for Select Subjects Array functions.
var select_subjects_array = [];
function findValueInSubject(value){
    var result = false;
    for(var i=0; i<select_subjects_array.length; i++){
        var name = select_subjects_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// Clears Subject Array Variables. 
function clear_subject_array(){
    select_subjects_array = [];
}

// Select Subjects from List. 
function select_subject(id){
    if(findValueInSubject(id)){
        var index = select_subjects_array.indexOf(id);
        if (index !== -1) {
            select_subjects_array.splice(index, 1);
        }
    }else{
        select_subjects_array.push(id);
    }
}

// Searct Subjects. 
function search_subject(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("admin/subjects.php", {subjects: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Add Subjects.
function add_subject(){
    loading_gif(true);
    $.post("admin/add_subject.php", {add_subject: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Try Add Subject.
function try_add_subject(){
    var subject = $("#subject_add").val();
    var subject_active = $("#subject_active").val();
    var subject_code = $("#subject_code").val();
    if(subject.trim() && subject_active.trim() && subject_code.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_add_subject: 1, subject: subject, subject_active: subject_active, subject_code: subject_code}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Subject added!");
                cancel(4);
            }else if(data == 2){
                alert("This subject is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Delete subject. 
function delete_subject() {
    if (select_subjects_array.length > 0) {
        var id_subject = select_subjects_array.toString();
        // Show a confirmation dialogue box before deleting
        var confirmed = confirm("Are you sure you want to delete the selected subjects?");
        if (confirmed) {
            loading_gif(true);
            $.post("admin/query.php", {try_delete_subject: 1, id_subject: id_subject}, function (data) {
                loading_gif(false);
                if (data == 1) {
                    alert("The selected subjects have been deleted!");
                    subjects_db();
                } else if (data == 0) {
                    alert("Error deleting selected subjects");
                }
            });
        }
    } else {
        alert("Please select at least one subject");
    }
}

// Edit Subject. 
function edit_subject(){
    if(select_subjects_array.length == 1){
        var id_subject = select_subjects_array.toString();
        loading_gif(true);
        $.post("admin/edit_subject.php", {edit_subject: 1, id_subject: id_subject}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one subject");
    }
}

// Try Edit Subject. 
function try_edit_subject(id){
    var subject = $("#subject_add").val();
    var subject_active = $("#subject_active").val();
    var subject_code = $("#subject_code").val();
    if(subject.trim() && subject_active.trim() && subject_code.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_edit_subject: 1, id_subject: id, subject: subject, subject_active: subject_active, subject_code: subject_code}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Changes applied!");
                cancel(4);
            }else if(data == 2){
                alert("This subject is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Mark inactive subject. 
function mark_inactive_subject(){
    if(select_subjects_array.length > 0){
        var id_subject = select_subjects_array.toString();
        loading_gif(true);
        $.post("admin/query.php", {try_inactive_subject: 1, id_subject: id_subject}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("The selected subjects have been deactivated!");
                subjects_db();
            }else if(data == 0){
                alert("Error, try again");
            }
        });
    }else{
        alert("Please select at least one subject");
    }
}

/*QUALIFICATIONS*/
// Variables for Select Qualification Arrray function. 
var select_qualifications_array = [];
function findValueInQualification(value){
    var result = false;
    for(var i=0; i<select_qualifications_array.length; i++){
        var name = select_qualifications_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// Clear Qualification Array. 
function clear_qualification_array(){
    select_qualifications_array = [];
}

// Selects qualifiatin array from list. 
function select_qualification(id){
    if(findValueInQualification(id)){
        var index = select_qualifications_array.indexOf(id);
        if (index !== -1) {
            select_qualifications_array.splice(index, 1);
        }
    }else{
        select_qualifications_array.push(id);
    }
}

// Search Qualification. 
function search_qualification(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("admin/qualifications.php", {qualifications: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Add Qualification. 
function add_qualification(){
    loading_gif(true);
    $.post("admin/add_qualification.php", {add_qualification: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Try Add Qualification. 
function try_add_qualification(){
    var qualification = $("#qualification_add").val();
    var qualification_active = $("#qualification_active").val();
    var qualification_description = $("#qualification_description").val();
    if(qualification.trim() && qualification_active.trim() && qualification_description.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_add_qualification: 1, qualification: qualification, qualification_active: qualification_active, qualification_description: qualification_description}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Qualification added!");
                cancel(5);
            }else if(data == 2){
                alert("This qualification is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Delete Qualification. 
function delete_qualification(){
    if(select_qualifications_array.length > 0){
        var id_qualification = select_qualifications_array.toString();
        // Add a confirmation dialogue box here
        if(confirm("Are you sure you want to delete the selected qualifications?")){
            loading_gif(true);
            $.post("admin/query.php", {try_delete_qualification: 1, id_qualification: id_qualification}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("The selected qualifications have been deleted!");
                    qualifications_db();
                }else if(data == 0){
                    alert("Error deleting selected qualifications");
                }
            });
        }
    }else{
        alert("Please select at least one qualification");
    }
}

// edit Qualification. 
function edit_qualification(){
    if(select_qualifications_array.length == 1){
        var id_qualification = select_qualifications_array.toString();
        loading_gif(true);
        $.post("admin/edit_qualification.php", {edit_qualification: 1, id_qualification: id_qualification}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one qualification");
    }
}

// try edit Qualification. 
function try_edit_qualification(id){
    var qualification = $("#qualification_add").val();
    var qualification_active = $("#qualification_active").val();
    var qualification_description = $("#qualification_description").val();
    if(qualification.trim() && qualification_active.trim() && qualification_description.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_edit_qualification: 1, id_qualification: id, qualification: qualification, qualification_active: qualification_active, qualification_description: qualification_description}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Changes applied!");
                cancel(5);
            }else if(data == 2){
                alert("This qualification is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Mark Inactive Qualification. 
function mark_inactive_qualification(){
    if(select_qualifications_array.length > 0){
        var id_qualification = select_qualifications_array.toString();
        loading_gif(true);
        $.post("admin/query.php", {try_inactive_qualification: 1, id_qualification: id_qualification}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("The selected qualifications have been deactivated!");
                qualifications_db();
            }else if(data == 0){
                alert("Error, try again");
            }
        });
    }else{
        alert("Please select at least one qualification");
    }
}

/*SCHEDULE*/
// Variables for Select schedule arrary function. 
var select_schedule_array = [];
function findValueInSchedule(value){
    var result = false;
    for(var i=0; i<select_schedule_array.length; i++){
        var name = select_schedule_array[i];
        if(name == value){
            result = true;
            break;
        }
    }
    return result;
}

// Clear Schedule Array function.
function clear_schedule_array(){
    select_schedule_array = [];
}

// Select Schedule from list. 
function select_schedule(id){
    if(findValueInSchedule(id)){
        var index = select_schedule_array.indexOf(id);
        if (index !== -1) {
            select_schedule_array.splice(index, 1);
        }
    }else{
        select_schedule_array.push(id);
    }
}

// Search Schedule. 
function search_schedule(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("admin/schedule.php", {schedule: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Search Schedule 2. 
function search_schedule2(){
    var key = $("#key_search").val();
    loading_gif(true);
    $.post("admin/scheduler.php", {scheduler: 1, key: key}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Add Schedule. 
function add_schedule(){
    loading_gif(true);
    $.post("admin/add_schedule.php", {add_schedule: 1}, function (data){
        loading_gif(false);
        $("#admin_show").html(data);
    });
}

// Try Add Schedule. 
function try_add_schedule(){
    var add_user_schedule = $("#add_user_schedule").val();
    var add_subject_schedule = $("#add_subject_schedule").val();
    var add_instance_schedule = $("#add_instance_schedule").val();
    var add_term_schedule = $("#add_term_schedule").val();
    var add_month_schedule = $("#add_month_schedule").val();
    var add_active = $("#add_active").val();
    if(add_instance_schedule.trim() && add_term_schedule.trim() && add_month_schedule.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_add_schedule: 1, add_user_schedule: add_user_schedule, add_subject_schedule: add_subject_schedule, add_instance_schedule: add_instance_schedule, add_term_schedule: add_term_schedule, add_month_schedule: add_month_schedule, add_active: add_active}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Schedule added!");
                cancel(6);
            }else if(data == 2){
                alert("This schedule is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Delete Schedule. 
function delete_schedule(){
    if(select_schedule_array.length > 0){
        var id_schedule = select_schedule_array.toString();
        // Show confirmation dialog box        
        if (confirm("Are you sure you want to delete the selected schedules?")) {
            loading_gif(true);
            $.post("admin/query.php", {try_delete_schedule: 1, id_schedule: id_schedule}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("The selected schedules have been deleted!");
                    schedule_db();
                }else if(data == 0){
                    alert("Error deleting selected schedules");
                }
            });
        }
    }else{
        alert("Please select at least one schedule");
    }
}


// Edit Schedule. 
function edit_schedule(){
    if(select_schedule_array.length == 1){
        var id_schedule = select_schedule_array.toString();
        loading_gif(true);
        $.post("admin/edit_schedule.php", {edit_schedule: 1, id_schedule: id_schedule}, function (data){
            loading_gif(false);
            $("#admin_show").html(data);
        });
    }else{
        alert("Please select one schedule");
    }
}

// Try Edit Schedule. 
function try_edit_schedule(id){
    var add_user_schedule = $("#add_user_schedule").val();
    var add_subject_schedule = $("#add_subject_schedule").val();
    var add_instance_schedule = $("#add_instance_schedule").val();
    var add_term_schedule = $("#add_term_schedule").val();
    var add_month_schedule = $("#add_month_schedule").val();
    var add_active = $("#add_active").val();
    if(add_instance_schedule.trim() && add_term_schedule.trim() && add_month_schedule.trim()){
        loading_gif(true);
        $.post("admin/query.php", {try_edit_schedule: 1, id_schedule: id, add_user_schedule: add_user_schedule, add_subject_schedule: add_subject_schedule, add_instance_schedule: add_instance_schedule, add_term_schedule: add_term_schedule, add_month_schedule: add_month_schedule, add_active: add_active}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("Changes applied!");
                cancel(6);
            }else if(data == 2){
                alert("This schedule is already present");
            }else{
                alert("Error, try again");
            }
        });
    }else{
        alert("Please complete all fields");
    }
}

// Mark Inactive Schedule. 
function mark_inactive_schedule(){
    if(select_schedule_array.length > 0){
        var id_schedule = select_schedule_array.toString();
        loading_gif(true);
        $.post("admin/query.php", {try_inactive_schedule: 1, id_schedule: id_schedule}, function (data){
            loading_gif(false);
            if(data == 1){
                alert("The selected schedules have been deactivated!");
                schedule_db();
            }else if(data == 0){
                alert("Error, try again");
            }
        });
    }else{
        alert("Please select at least one schedule");
    }
}

/*PROFILE - Displays option to modify user password to new password */
function try_modify_psw(){
    var old_psw = $("#old_psw").val();
    var new_psw = $("#new_psw").val();
    var confirm_psw = $("#confirm_psw").val();
    if(old_psw.trim() && new_psw.trim() && confirm_psw.trim()){
        if(new_psw == confirm_psw){
            loading_gif(true);
            $.post("admin/query.php", {try_modify_psw: 1, old_psw: old_psw, new_psw: new_psw}, function (data){
                loading_gif(false);
                if(data == 1){
                    alert("Your password has been changed!");
                    select_menu(2);
                }else if(data == 0){
                    alert("Error, try again");
                }else if(data == 2){
                    alert("The old password does not match!");
                }
            });
        }else{
            alert("Passwords don't match");
        }
    }else{
        alert("Please complete all fields");
    }
}