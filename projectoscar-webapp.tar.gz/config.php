<?php

    /* 
        Author: Charlie Isaac.
        Student ID: 20220376.

        Author: John Sims.
        Student ID: 20224767.

        Description: This file contains the web applications database configuration settings.
    */

    // DATABASE CONFIGURATION SETTINGS - Connects to MariaDB RDS on AWS. 

    $nome_db = "StaffScheduler";
    $psw_db = "MyTi4CNtPimf7jqiGpRStQB9kfxDfkpSNkMHnHjz";
    $username_db = "root";
    $host_db = "projectoscar-scheduling-db.cr0ijhceyk4l.ap-southeast-2.rds.amazonaws.com";
    
    // connect to the database
    $conn = mysqli_connect($host_db, $username_db, $psw_db, $nome_db);

    // set the character set to utf8
    mysqli_set_charset($conn, "utf8");

    // check if the connection failed version 2 recommend.
    if (mysqli_connect_errno()) {
        // if the connection failed, display an error message and exit the script
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }
    
?>