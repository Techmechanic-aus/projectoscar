<?php
    // Start the session
    session_start();

    // Include the database connection
    include "config.php";

    // Check if the form was submitted
    if(isset($conn) && isset($_POST["login"])){

        // Sanitize and validate user input        
        $email = strtoupper($_POST["email"]);
        $psw = strval($_POST["psw"]);

        // Query the database for the user with the given email and password
        $sql = mysqli_query($conn, "SELECT id, id_role, active FROM user WHERE email='$email' AND psw='$psw'");
        
        // If there is a match, log in the user        
        if(mysqli_num_rows($sql) == 1){
            $user = mysqli_fetch_array($sql, MYSQLI_ASSOC);

            if($user["active"] == 0){

                echo -2; // User is not active, return -2

            }else{
                // User is active, set session variables and return their role ID
                $_SESSION["email"] = $email;
                $_SESSION["psw"] = $psw;
                $_SESSION["id"] = $user["id"];
                $_SESSION["id_role"] = $user["id_role"];
                echo $user["id_role"];
            }
        }else{
            // No match found, return -1
            echo -1;
        }
    }

?>