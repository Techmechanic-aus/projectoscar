<?php
    /*      
        Author: Charlie Isaac.
        Student ID: 20220376.

        Author: John Sims.
        Student ID: 20224767.

        Description: This file contains the main web applications index page (login) .
    */


    // User Session ID / Single Login 
    session_start();  
    
        // Expire the cookie to delete the session ID
        setcookie(session_name(), '', time()-3600, '/');
        
        // Generate a new session ID
        session_regenerate_id(true);
        
        /* used to write the session data and end the session. 
        This is important to ensure that the new session is properly saved. */
        session_write_close();

?>

<!-- USER LOGIN PAGE FORM - WHERE USER ENTERS WEB APPLICATION. -->

<!-- HTML - Header and Body Sections -->
<!doctype html>
<html lang="en">

    <!-- Header Content Section -->
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">

        <!-- Icon for bookmark logo  -->
        <link rel="icon" type="image/x-icon" href="img/logo.png">

       <!-- Page Title Top Browser / Tab -->     
        <title>Diasko | Staff Scheduler - Login</title>

        <!-- JQuery library  -->
        <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

        <!-- JQuery Scripts for php page functions  -->
        <script src="js/index.js"></script>

         <!-- Bootstrap css - latest version v5.3.0-alpha1 -->       
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
        
        <!-- Custom styles for this template -->
        <link href="css/sign-in.css" rel="stylesheet">
        <link href="css/flexbox.css" rel="stylesheet">
        <link href="css/loading.css" rel="stylesheet">
        <link href="css/extras.css" rel="stylesheet">

    </head>

    <!-- HTML BODY - Where content appears -->
    <body class="text-center">

        <!-- Loading Spinnng Icon when switching .php pages -->
        <div class="loading">
                <div class="max_width max_height center_col">
                <img src="img/loading.svg" style="width: 80px;">
            </div>
        </div>

        <!-- Login Form Section -->
        <!-- Main - Class CSS for Form --> 
        <main class="form-signin w-100 m-auto">
            <div>
                <!-- Login - TEXT - "PLEASE SIGN IN" and Diasko - Staff Scheduler Logo -->
                <img class="mb-4" src="img/logo2.png" alt="" width="300">
                <h1 class="h3 mb-3 fw-normal">Please sign in</h1>

                <!-- EMAIL TEXT and BOX -->
                <div class="form-floating">
                    <input id="email" type="email" class="form-control" placeholder="name@example.com">
                    <label for="floatingInput">Email address</label>
                </div>

                <!-- PASSWORD TEXT and BOX -->
                <div class="form-floating">
                    <input id="psw" type="password" class="form-control" placeholder="Password">
                    <label for="floatingPassword">Password</label>
                </div>

                <!-- Possible TEXT and URL LiNK AREA before signin button -->
                <div class="mb-3 end_row">
 
                </div>

                <!-- SIGN IN BUTTON -->
                <button class="w-100 btn btn-lg btn-primary" type="submit" onclick="try_login()">Sign in</button>

             </div>
        </main>
    </body>
</html>
